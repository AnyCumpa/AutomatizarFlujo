# Template base para pruebas automatizadas a nivel de servicios

El ojetivo del presente template es mostrar una estructura de trabajo que pueda
ser unifome en todos los proyectos de pruebas automatizas a nivel de servicios
para el banco Interbank.

- [Arquitectura de Pruebas Automatizadas de servicios](#arquitectura-de-pruebas-automatizadas-de-servicios)
- [Diagrama de la Arquitectura de Pruebas Automatizadas](#diagrama-de-la-arquitectura-de-pruebas-automatizadas)
- [Conceptos Importantes](#conceptos-importantes)
- [Estructura del Template](#estructura-del-template-de-pruebas)
- [Dependencias y plugins del proyecto](#dependencias-y-plugins-del-proyecto)
- [Uso del Framework](#uso-del-framework)
- [Problemas Frecuentes](#problemas-frecuentes)
- [Contacto](#contacto)

## Arquitectura de Pruebas Automatizadas de servicios

> El detalle de las capas de la arquitectura y stack tecnológico se puede ver en el siguiente [link](https://interbankpe.sharepoint.com/:p:/r/sites/CoordinacinInternaDevOpsArquitectura/Shared%20Documents/General/Framework/Estandares/Testing/Lineamientos%20para%20implementaci%C3%B3n%20de%20pruebas%20automatizadas%20v0.1.pptx?d=wfd038a9ab41b4d87af4d2188fff772f9&csf=1&web=1&e=PZSIuS).

## Diagrama de la Arquitectura de Pruebas Automatizadas

![arquitectura.png](doc/image/arquitectura_template.png)

## Conceptos Importantes

### Screenplay

El template de pruebas automatizadas para servicios es trabajado con el patrón de diseño Screenplay.

> Para conocer acerca del patrón de diseño Screenplay ver el siguiente [link](doc/conceptos-importantes/patron-screeenplay.md)

### Behavior Driven Development (BDD)

Se usa esta metodología para el entendmiento mutuo de las reglas del negocio, es importante seguir el flujo
correctamente antes de la automatización.

> Para conocer los conceptos del desarrollo orientado al comportamiento ver el siguiente [link](doc/conceptos-importantes/bdd.md).

### JSON Schemas

El proyecto de automatización tiene implementado un método para validar el JSON Schema de un response siguiendo el
patrón de diseño Screenplay.

> Para conocer la aplicación de los JSON Scehmas ver el siguiente [link](doc/conceptos-importantes/json-schemas.md)

### Templates

Para realizar consultas se propone trabajar el cuerpo de los requests con templates del cuerpo del request en caso sea
JSON.

> Para conocer la manera en la que se trabajan los templates de los request ver el siguiente [link](doc/conceptos-importantes/template-request.md).

### GraphQL

El proyecto actualmente trabaja con templates para realizar querys de GraphQL.

> Para conocer cómo se manejan los querys de GraphQL en el proyecto ver el siguiente [link](doc/conceptos-importantes/graphql.md)

### Git

> Para conocer el flujo de trabajo y algunas convenciones con Git ver el siguiente [link](doc/conceptos-importantes/git.md).

## Estructura del template de pruebas

El template de pruebas automatizadas cuenta con la siguiente estructura:

````text 
dso-api-testing/                        
├───devops                          
│   ├───pipelines                   
│   └───templates                   
│       └───jobs                    
├───doc   
├───src                             
│   └───test                        
│       ├───java                    
│       │   └───pe                  
│       │       └───interbank
│       │           └───testing
│       │               ├───dao
│       │               ├───endpoint
│       │               ├───model
│       │               ├───question
│       │               │   └───generic
│       │               ├───runner
│       │               ├───stepdefinition
│       │               ├───task
│       │               └───util
│       └───resources
│           ├───asset
│           ├───feature
│           ├───schema
│           └───template
│               ├───api
│               └───graphql
│                   └───entity
│                       ├───query
│                       └───variable
└─── 
````

> Para ver el detalle de la función de cada carpeta en el proyecto ver el siguiente [link](doc/estructura-proyecto/estructura-proyecto.md).

## Dependencias y plugins del proyecto

### Dependencias

| Dependencias             | Versión      | Descripción del uso                                                                                                                                                                                                                      |
|--------------------------|--------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| serenity-core            | v3.6.12      | Serenity Core proporciona capacidades (métodos, claess, anotaciones, etc) esenciales para ejecutar pruebas automatizadas y generar informes detallados.                                                                                  | 
| serenity-junit           | v3.6.12      | Serenity JUnit es una extensión de Serenity Core que permite ejecutar pruebas automatizadas utilizando el framework JUnitv4.                                                                                                             | 
| serenity-screenplay      | v3.6.12      | Serenity Screenplay es una extensión de Serenity Core que proporciona un enfoque basado en el patrón de diseño Screenplay para escribir pruebas automatizadas más legibles y mantenibles.                                                | 
| serenity-screenplay-rest | v3.6.12      | Serenity Screenplay Rest es una extensión de Serenity Screenplay que permite realizar pruebas automatizadas de servicios REST.                                                                                                           | 
| serenity-cucumber        | v3.6.12      | Serenity Cucumber es una extensión de Serenity Core que permite ejecutar pruebas automatizadas utilizando el Cucumber. Esta librería requiere de un runner, sea JUnit4 o JUnit5.                                                         | 
| cucumber-java            | v7.11.1      | Cucumber Java es la implementación de Cucumber para trabajar con Java. Se utiliza para escribir y ejecutar escenarios de prueba en estilo BDD utilizando el lenguaje Gherkin. Se requiere de esta librería si se usa sererenity-cucumber | 
| json-schema-validator    | v5.3.0       | Esta es una librería para obtener los métodos para comparar el esquema de un JSON con un request o response de un API.                                                                                                                   | 
| mssql-jdbc               | v12.2.0.jre8 | Esta dependencia permite establer la conexiones a bases de datos SQL Server.                                                                                                                                                             | 
| httpclient5              | v5.2.1       | Esta es una librería únicamente usada para realizar las consultas a las APIs de Xray y Jira.                                                                                                                                             | 
| hamcrest                 | v2.2         | Esta dependencia proporciona un conjunto de métodos para realizar assertions más legibles y expresivas en la implementación de las pruebas.                                                                                              | 

### Plugins

| Plugins               | Descripción del uso                                                                                                                                                                        |
|-----------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| maven-surefire-plugin | Este plugin se utiliza para ejecutarlas pruebas unitarias escritas en el proyecto.                                                                                                         |
| maven-failsafe-plugin | Este plugin es usado para ejecutar preubas de integración en el proyecto. Permite la ejecución de pruebas que requieren un entorno más amplio (BD, API, etc).                              |
| maven-compiler-plugin | Este se utilizapara compilar el proyecto. Además, permite opciones de configuración para especificar la versión del compilador de Java y otros parámetros de configuración del compilador. |
| serenity-maven-plugin | Este plugin es especifíco de Serenity y se utiliza para generar los informes al ejecutar las pruebas.                                                                                      |

## Uso del framework

### Configuraciones previas

Antes de realizar la ejecución del proyecto se debe configurar la versión adecuada del JDK y del Maven.

> Para ver las configuraciones necesarias para el proyecto ver el siguiente [link](doc/uso-framework/configuraciones-previas.md).

### Ejecutar el proyecto

Para ejecutar el proyecto de manera local y generar el reporte puede usar el siguiente comando.

```shell
mvn clean verify "-Dcucumber.filter.tags=@regresion" -f pom.xml
```

### Reporte de ejecución

Para el template de pruebas automatizadas de servicios se personlizo el reporte brindado por Serenity

> Para ver cuáles son las secciones que configuraron dar click en el siguiente [link](doc/uso-framework/reporte-ejecucion.md).

## Integraciones

### Xray y Jira

El template de automatización de pruebas de servicios, actualmente cuenta con la integración con Xray, gestor de casos
de pruebas, y Jira, gestor de proyectos.

> Para revisar la integración con Xray y Jira ver el siguiente [link](doc/xray-jira-integration/xray-jira-integration.md).

### Base de datos

El template de pruebas automatizadas cuanta también con la posibilidad de conectarse a una base de datos, para esto se
tiene un flujo respetando el patrón de diseño, Screenplay

> Para revisar la integración con la base de datos ver el siguiente [link](doc/bd-integration/bd-integration.md).

## Problemas frecuentes

En esta sección se pueden visualizar los problemas más comunes y su solución al momento de automatizar una HUs.

> Para revisar cuáles son los problemas más frecuentes al momento de implementar escenarios con el proyecto ver el siguiente [link](doc/problemas-frecuentes/problemas-frecuentes.md).

## Contacto

Para mejoras, dudas o consultas hacerlo al equipo de Arquitectura:

| Miembros del equipo de Arquitectura           | Correo corporativo                  |
|-----------------------------------------------|-------------------------------------|
| Guevara Lizarraga, Maria Fernanda Del Milagro | mguevarali@intercorp.com.pe         |
| Romucho Velasco, Joham Enrique                | jromucho@proveedor.intercorp.com.pe |
