package pe.interbank.testing.util;

import org.apache.hc.client5.http.ClientProtocolException;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.entity.mime.FileBody;
import org.apache.hc.client5.http.entity.mime.MultipartEntityBuilder;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.HttpHost;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.StringEntity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Utility class for interacting with Xray, a test management tool, and Jira, a project management tool.
 * This class provides various methods for importing test execution results, attaching evidence to test executions,
 * synchronizing test features, and performing authentication with Xray and Jira.
 * <p>
 * Usage: This class can be used to automate test result imports, evidence attachments, and feature synchronization
 * with Xray using the provided methods.
 * <p>
 * Note: The environment variables XRAY_HOSTNAME, JIRA_HOSTNAME, JIRA_USERNAME, JIRA_API_TOKEN, JIRA_CLIENT_ID,
 * PROJECT_ID, PROJECT_KEY, REPOSITORY_NAME, and JIRA_CLIENT_SECRET need to be set appropriately for the class to work correctly.
 * </p>
 * <p>
 *  For more information on Xray's API, refer to the <a href="https://docs.getxray.app/display/XRAYCLOUD/API">Xray API documentation</a>.
 *  For more information on Jira's REST API, refer to the <a href="https://developer.atlassian.com/cloud/jira/platform/rest/v3/intro/#about">Jira REST API documentation</a>.
 * </p>
 *
 * @author Joham Romucho
 */
public class XrayUtil {

    // Constants for file paths and environment variable names
    private final static String ROOT_DIRECTORY = System.getProperty("user.dir");
    private final static String PATH_SERENITY_REPORT = "target/site/serenity";
    private final static String PATH_SERENITY_REPORT_ZIP = "target/evidence-test-execution.zip";
    private final static String PATH_FEATURES = "src/test/resources/feature";
    private final static String PATH_FEATURES_ZIP = "target/features.zip";
    private final static String XRAY_HOSTNAME = System.getenv("XRAY_HOSTNAME");
    private final static String JIRA_HOSTNAME = System.getenv("JIRA_HOSTNAME");
    private final static String JIRA_USERNAME = System.getenv("JIRA_USERNAME");
    private final static String JIRA_API_TOKEN = System.getenv("JIRA_API_TOKEN");
    private final static String JIRA_CLIENT_ID = System.getenv("JIRA_CLIENT_ID");
    private final static String PROJECT_ID = System.getenv("PROJECT_ID");
    private final static String PROJECT_KEY = System.getenv("PROJECT_KEY");
    private final static String REPOSITORY_NAME = System.getenv("REPOSITORY_NAME");
    private final static String JIRA_CLIENT_SECRET = System.getenv("JIRA_CLIENT_SECRET");
    private final static String CUCUMBER_REPORT_PATH = "/target/cucumber/cucumber.json";

    /**
     * Private constructor to prevent instantiation of the XrayUtil class.
     * All methods in this class are static, so there is no need to create an instance of this class.
     */
    private XrayUtil() {
    }

    /**
     * Reads the contents of a cucumber JSON file and returns it as a string.
     *
     * @param cucumberJsonFile The path to the cucumber JSON file.
     * @return The contents of the cucumber JSON file as a string.
     * @throws RuntimeException If an error occurs while reading the file.
     */
    public static String getCucumberJsonContentAsString(String cucumberJsonFile) {
        Path cucumberPath = Path.of(ROOT_DIRECTORY + cucumberJsonFile);
        try {
            return Files.readString(cucumberPath, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Something went wrong");
        }
    }

    /**
     * Performs Xray token authentication by sending a POST request to the Xray API.
     *
     * @return The Xray token obtained after successful authentication.
     * @throws Exception If an error occurs during the authentication process.
     */
    public static String getXrayTokenAuthentication() throws Exception {
        String path = "/api/v1/authenticate";

        String requestBody = "{\"client_id\": \"" + JIRA_CLIENT_ID + "\", \"client_secret\": \"" + JIRA_CLIENT_SECRET + "\"}";
        String token = "";

        try (final CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(path);
            HttpHost targetHost = new HttpHost("https", XRAY_HOSTNAME);

            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-Type", "application/json");

            StringEntity requestEntity = new StringEntity(requestBody);
            httpPost.setEntity(requestEntity);

            System.out.println("Executing request " + httpPost.getMethod() + " " + httpPost.getUri());
            token = httpclient.execute(targetHost, httpPost, response -> EntityUtils.toString(response.getEntity()));
            System.out.println("Result: " + token + "\n");

        }
        return token.substring(1, token.length() - 1);
    }

    /**
     * Imports the test execution results from a cucumber JSON file to Xray.
     *
     * @return The response string from the Xray API after importing the results.
     * @throws Exception If an error occurs during the import process.
     */
    public static String importTestExecutionResults() throws Exception {
        String path = "/api/v1/import/execution/cucumber";

        String requestBody = getCucumberJsonContentAsString(CUCUMBER_REPORT_PATH);
        String token = getXrayTokenAuthentication();

        String responseString = "";

        try (final CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(path);
            HttpHost targetHost = new HttpHost("https", XRAY_HOSTNAME);

            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-Type", "application/json");
            httpPost.setHeader("Authorization", "Bearer " + token);

            StringEntity requestEntity = new StringEntity(requestBody);
            httpPost.setEntity(requestEntity);

            System.out.println("Executing request " + httpPost.getMethod() + " " + httpPost.getUri());
            responseString = httpclient.execute(targetHost, httpPost, response -> EntityUtils.toString(response.getEntity()));
            System.out.println("Result: " + responseString + "\n");
        }
        return responseString;
    }

    /**
     * Attaches evidence to a specific test execution in Jira by uploading the serenity report as a zip file.
     *
     * @param keyTE The key of the test execution in Jira.
     * @throws Exception If an error occurs while attaching the evidence.
     */
    public static void attachEvidence(String keyTE) throws Exception {
        String path = "/rest/api/3/issue/" + keyTE + "/attachments";
        String responseString = "";

        zipDirectory(Paths.get(PATH_SERENITY_REPORT), Paths.get(PATH_SERENITY_REPORT_ZIP));

        File serenityReport = new File(ROOT_DIRECTORY + "/" + PATH_SERENITY_REPORT_ZIP);

        try (CloseableHttpClient httpClient = HttpClients.custom().build()) {
            HttpPost request = new HttpPost(path);
            HttpHost targetHost = new HttpHost("https", JIRA_HOSTNAME);

            request.setHeader("X-Atlassian-Token", "no-check");
            request.setHeader("Authorization", getBasicAuthenticationToken(JIRA_USERNAME, JIRA_API_TOKEN));

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();

            FileBody fileBody = new FileBody(serenityReport, ContentType.APPLICATION_OCTET_STREAM, serenityReport.getName());
            builder.addPart("file", fileBody);

            request.setEntity(builder.build());
            System.out.println("Executing request " + request.getMethod() + " " + request.getUri());
            responseString = httpClient.execute(targetHost, request, response -> EntityUtils.toString(response.getEntity()));
            System.out.println("Result: " + responseString + "\n");

        } catch (URISyntaxException | ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Synchronizes test features with Xray by uploading a zip file containing feature files.
     *
     * @throws Exception If an error occurs during the synchronization process.
     */
    public static void synchronizingFeatures() throws Exception {
        String path = "/api/v1/import/feature";
        String params = "?projectKey=" + PROJECT_KEY + "&projectId=" + PROJECT_ID + "&source=" + REPOSITORY_NAME;
        String token = getXrayTokenAuthentication();
        String responseString = "";

        zipDirectory(Paths.get(PATH_FEATURES), Paths.get(PATH_FEATURES_ZIP));

        File featuresZip = new File(ROOT_DIRECTORY + "/" + PATH_FEATURES_ZIP);
        try (CloseableHttpClient httpClient = HttpClients.custom()
                .build()) {

            HttpPost request = new HttpPost(path + params);
            HttpHost targetHost = new HttpHost("https", XRAY_HOSTNAME);

            request.setHeader("Authorization", "Bearer " + token);

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();

            FileBody fileBody = new FileBody(featuresZip, ContentType.APPLICATION_OCTET_STREAM, featuresZip.getName());
            builder.addPart("file", fileBody);

            request.setEntity(builder.build());
            System.out.println("Executing request " + request.getMethod() + " " + request.getUri());
            responseString = httpClient.execute(targetHost, request, response -> EntityUtils.toString(response.getEntity()));
            System.out.println("Result: " + responseString + "\n");

        } catch (URISyntaxException | ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Zips a directory and its contents into a zip file.
     *
     * @param directoryPath The path of the directory to zip.
     * @param zipFilePath   The path of the resulting zip file.
     * @throws IOException If an I/O error occurs during the zip operation.
     */
    public static void zipDirectory(Path directoryPath, Path zipFilePath) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(zipFilePath.toFile());
             ZipOutputStream zipOut = new ZipOutputStream(fos)) {
            Files.walk(directoryPath)
                    .filter(path -> !Files.isDirectory(path))
                    .forEach(path -> {
                        ZipEntry zipEntry = new ZipEntry(directoryPath.relativize(path).toString());
                        try {
                            zipOut.putNextEntry(zipEntry);
                            zipOut.write(Files.readAllBytes(path));
                            zipOut.closeEntry();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
        }
    }

    /**
     * Generates a basic authentication token using the provided username and password.
     *
     * @param username The username for authentication.
     * @param password The password for authentication.
     * @return The basic authentication token.
     */
    public static String getBasicAuthenticationToken(String username, String password) {
        String valueToEncode = username + ":" + password;
        return "Basic " + Base64.getEncoder().encodeToString(valueToEncode.getBytes());
    }
}
