package pe.interbank.testing.dao;

import com.azure.cosmos.implementation.Utils;
import com.azure.cosmos.models.CosmosQueryRequestOptions;
import com.azure.cosmos.models.FeedResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import pe.interbank.testing.model.Res;
import pe.interbank.testing.util.DBCosmos;

import java.util.ArrayList;
import java.util.List;

public class ResDao extends DBCosmos {

    private static final ObjectMapper OBJECT_MAPPER = Utils.getSimpleObjectMapper();
    private final static String CONTAINER_NAME = "load-res-cts";


    public static List<Res> getResForRuc(String ruc) {

        List<Res> resItems = new ArrayList<>();
        CosmosQueryRequestOptions queryOptions = new CosmosQueryRequestOptions();
        queryOptions.setQueryMetricsEnabled(true);

        int maxItemCount = 1000;
        int maxDegreeOfParallelism = 1000;
        int maxBufferedItemCount = 100;

        CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
        options.setMaxBufferedItemCount(maxBufferedItemCount);
        options.setMaxDegreeOfParallelism(maxDegreeOfParallelism);
        options.setQueryMetricsEnabled(false);

        int error_count = 0;
        int error_limit = 10;

        String continuationToken = null;
        do {

            String sql = "SELECT * FROM root r WHERE r.documentNumber = '" + ruc + "'";

            for (FeedResponse<JsonNode> pageResponse :
                    getContainerCreateResourcesIfNotExist(CONTAINER_NAME)
                            .queryItems(sql, options, JsonNode.class)
                            .iterableByPage(continuationToken, maxItemCount)) {

                continuationToken = pageResponse.getContinuationToken();

                for (JsonNode item : pageResponse.getElements()) {

                    try {
                        resItems.add(OBJECT_MAPPER.treeToValue(item, Res.class));
                    } catch (JsonProcessingException e) {
                        if (error_count < error_limit) {
                            error_count++;
                            if (error_count >= error_limit) {
                                System.out.println("\n...reached max error count.\n");
                            } else {
                                System.out.println("Error deserializing TODO item JsonNode. " +
                                        "This item will not be returned.");
                                e.printStackTrace();
                            }
                        }
                    }

                }
            }

        } while (continuationToken != null);

        return resItems;
    }

}
