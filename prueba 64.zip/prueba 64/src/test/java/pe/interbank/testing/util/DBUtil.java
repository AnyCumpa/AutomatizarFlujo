package pe.interbank.testing.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Logger;

import static pe.interbank.testing.endpoint.BaseUrl.getBDUrl;


public class DBUtil {
    private static final Logger log;

    static {
        System.setProperty("java.util.logging.SimpleFormatter.format", "[%4$-7s] %5$s %n");
        log = Logger.getLogger(DBUtil.class.getName());
    }

    public static Connection getConnection() throws Exception {
        log.info("Connecting to the database");
        String user = System.getenv("BD_USERNAME");
        String password = System.getenv("BD_PASSWORD");
        String url = getBDUrl();
        return DriverManager.getConnection(url, user, password);
    }

}
