package pe.interbank.testing.util;

import io.cucumber.datatable.DataTable;
import org.apache.commons.io.IOUtils;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * This class provides utility methods for common operations in Java.
 * It contains methods for loading properties, retrieving templates, queries, and variables,
 * generating random numbers and codes, converting lists to strings, and parsing data tables.
 * The methods in this class are static and can be accessed without creating an instance of the class.
 * @author Joham Romucho
 */
public class JavaUtil {

    /**
     * Private constructor to prevent instantiation of the JavaUtil class.
     * All methods in this class are static, so there is no need to create an instance of this class.
     */
    private JavaUtil() {
    }

    /**
     * This method loads the serenity.properties file and returns the properties as a {@link Properties} object.
     *
     * @return The loaded properties from serenity.properties file.
     * @throws IOException if an I/O error occurs while reading the file.
     */
    public static Properties properties() throws IOException {

        Properties properties = null;
        try {
            properties = new Properties();
            String propFileName = "serenity.properties";

            properties.load(new FileReader(propFileName));

        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }

        return properties;
    }

    /**
     * This method retrieves the contents of a template file as a string.
     *
     * @param templatePath The path to the template file. The template file should be located in the "src/test/resources/template" package.
     * @return The contents of the template file as a string.
     * @throws RuntimeException if an I/O error occurs while reading the file.
     */
    public static String getTemplate(String templatePath) {
        try {
            return IOUtils.toString(JavaUtil.class.getResourceAsStream(templatePath), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Retrieves the contents of a query file as a string and optionally appends a fragment to it.
     *
     * @param query The path to the query file. The query file should be located in the "src/test/resources/template/graphql" package.
     * @param fragment An optional fragment to append to the query. The fragment file should be located in the "src/test/resources/template/graphql" package.
     * @return The contents of the query file as a string, with the fragment appended if provided.
     * @throws RuntimeException if an I/O error occurs while reading the file.
     */
    public static String getQuery(String query, Optional<String> fragment) {
        String queryStr;
        try {
            queryStr = IOUtils.toString(JavaUtil.class.getResourceAsStream(query), StandardCharsets.UTF_8).replaceAll("\r\n", "");
            if (fragment.isPresent()) {
                queryStr = queryStr + "\n" + fragment;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return queryStr;
    }

    /**
     * Retrieves the contents of a variables file as a string.
     *
     * @param variablesPath The path to the variables file.
     *                      The variables file should be located in the "src/test/resources/template/graphql" package.
     * @return The contents of the variables file as a string.
     * @throws RuntimeException if an I/O error occurs while reading the file.
     */
    public static String getVariables(String variablesPath) {
        try {
            String variables = IOUtils.toString(JavaUtil.class.getResourceAsStream(variablesPath), StandardCharsets.UTF_8)
                    .replaceAll("\r\n", " ")
                    .replaceAll("\"", "\\\\\"");
            return variables;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * This method generates a random number with the specified length.
     *
     * @param length The length of the random number.
     * @return A random number with the specified length.
     */
    public static Integer getRandomNumber(int length){
        int min = (int) Math.pow(10, length - 1); // Minimum value based on length
        int max = (int) Math.pow(10, length) - 1; // Maximum value based on length

        Random random = new Random();
        return random.nextInt(max - min + 1) + min;
    }

    /**
     * This method converts a list to a string representation.
     *
     * @param list The list to convert.
     * @param <T>  The type of elements in the list.
     * @return A string representation of the list.
     */
    public static <T> String listToString(List<T> list) {
        if(!list.isEmpty()){
            return "[" + String.join(", ", list.toString()) + "]";
        }else{
            return list.toString();
        }
    }

    /**
     * This method parses a DataTable object into a list of strings.
     *
     * @param table The DataTable object to parse.
     * @return A list of strings representing the extracted values from the DataTable.
     */
    public static List<String> parseDataTableIntoAStringList(DataTable table) {
        List<List<String>> listOfLists = table.asLists();
        return listOfLists.stream()
                .map(row -> row.get(0))
                .collect(Collectors.toList());
    }

    /**
     * This method generates a random code with the specified initial message and code length.
     *
     * @param initialMessage The initial message for the code.
     * @param codeLength     The length of the generated code.
     * @return The generated random code.
     */
    public static String generateRandomCode(String initialMessage, int codeLength) {
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvxyz";
        StringBuilder sb = new StringBuilder(codeLength);
        for (int i = 0; i < codeLength; i++) {
            int index = (int)(AlphaNumericString.length() * Math.random());
            sb.append(AlphaNumericString.charAt(index));
        }
        return initialMessage+ sb;
    }

}
