package pe.interbank.testing.util;

/**
 * The ApiCommon class provides common constants used in API development.
 * It includes status codes commonly used in HTTP responses and error messages customizable per business.
 * @author Joham Romucho
 */
public final class ApiCommon {

    /**
     * HTTP status code for Unauthorized (100) response.
     * It indicates that the client should continue the request or ignore the response if the request is already finished.
     */
    public static final int STATUS_CODE_CONTINUE = 100;

    /**
     * HTTP status code for Unauthorized (101) response.
     * This code is sent in response to an Upgrade request header from the client and indicates the protocol the server is switching to.
     */
    public static final int STATUS_CODE_SWITCHING_PROTOCOL = 101;

    /**
     * HTTP status code for Unauthorized (102) response.
     * This code indicates that the server has received and is processing the request, but no response is available yet.
     */
    public static final int STATUS_CODE_PROCESSING = 102;

    /**
     * HTTP status code for Unauthorized (103) response.
     * This status code is primarily intended to be used with the Link header, letting the user agent start preloading resources while the server prepares a response.
     */
    public static final int STATUS_CODE_EARLY_HINTS = 103;

    /**
     * HTTP status code for Unauthorized (200) response.
     * This status code indicates that the request succeed
     */
    public static final int STATUS_CODE_OK = 200;

    public static final int STATUS_CODE_INVALID_USERNAME = 401 ;

    /**
     * HTTP status code for Unauthorized (201) response.
     * This status code indicates that the request succeeded, and a new resource was created as a result.
     */
    public static final int STATUS_CODE_CREATED = 201;

    /**
     * HTTP status code for Unauthorized (202) response.
     * This status code indicates that the request has been received but not yet acted upon.
     */
    public static final int STATUS_CODE_ACCEPTED = 202;

    /**
     * HTTP status code for Unauthorized (203) response.
     * This response code means that the returned metadata is not exactly the same as is available from the origin server, but is collected from a local or a third-party copy.
     */
    public static final int STATUS_CODE_NON_AUTHORATIVE_INFORMATION = 203;

    /**
     * HTTP status code for Unauthorized (204) response.
     * This response code means that there is no content to send for this request body.
     */
    public static final int STATUS_CODE_NO_CONTENT = 204;

    /**
     * HTTP status code for Unauthorized (205) response.
     * This response code indicates that the server has fulfilled the request and requires the requester to reset the document view.
     */
    public static final int STATUS_CODE_RESET_CONTENT = 205;

    /**
     * HTTP status code for Partial Content (206) response.
     * This response code indicates that the server is delivering only a portion of the requested resource in the response.
     */
    public static final int STATUS_CODE_PARTIAL_CONTENT = 206;

    /**
     * HTTP status code for Multi-Status (207) response.
     * This response code indicates that the response returned may contain multiple independent responses.
     */
    public static final int STATUS_CODE_MULTI_STATUS = 207;

    /**
     * HTTP status code for Unauthorized (208) response.
     * This response code appears in a multi status response to indicates that the resource has already answer
     */
    public static final int STATUS_CODE_ALREADY_REPORTED = 208;

    /**
     * HTTP status code for IM Used (226) response.
     * This response code indicates that the server has fulfilled a request for the resource, and the response is a representation of the result of one or more instance manipulations applied to the current instance.
     */
    public static final int STATUS_CODE_IM_USED = 226;

    /**
     * HTTP status code for Bad Request (400) response.
     * This response code indicates that the server cannot process the request due to malformed syntax or other client error.
     */
    public static final int STATUS_CODE_BAD_REQUEST = 400;

    /**
     * HTTP status code for Unauthorized (401) response.
     * This response code indicates that the client must authenticate to get the requested response.
     */
    public static final int STATUS_CODE_UNAUTHORIZED = 401;

    /**
     * HTTP status code for Payment Required (402) response.
     * This response code is reserved for future use and is typically used for digital payment schemes.
     */
    public static final int STATUS_PAYMENT_REQUIRED = 402;

    /**
     * HTTP status code for Unauthorized (403) response.
     * This response code indicates that the user doesn't have access to the content requested so the server is refusing to give the requested resource.
     */
    public static final int STATUS_CODE_FORBIDDEN = 403;

    /**
     * HTTP status code for Unauthorized (404) response.
     * This response code indicates that the server can not find the requested resource (URL).
     */
    public static final int STATUS_CODE_NOT_FOUND = 404;

    /**
     * HTTP status code for Method Not Allowed (405) response.
     * This response code indicates that the method specified in the request is not allowed for the resource.
     */
    public static final int STATUS_CODE_METHOD_NOT_ALLOWED = 405;

    /**
     * HTTP status code for Not Acceptable (406) response.
     * This response code indicates that the server cannot produce a response matching the list of acceptable values defined in the request's headers.
     */
    public static final int STATUS_CODE_NOT_ACCEPTABLE = 406;

    /**
     * HTTP status code for Unauthorized (407) response.
     * This response code indicates that authentication need to be done by the proxy.
     */
    public static final int STATUS_CODE_PROXY_AUTHENTICATION_REQUIRED = 407;

    /**
     * HTTP status code for Unauthorized (408) response.
     * This response code means that indicates that
     */
    public static final int STATUS_CODE_REQUEST_TIMEOUT = 408;

    /**
     * HTTP status code for Unauthorized (409) response.
     * This response code is sent on an idle connection with the server.
     */
    public static final int STATUS_CODE_CONFLICT = 409;

    /**
     * HTTP status code for Gone (410) response.
     * This response code indicates that the requested resource is no longer available and will not be available again.
     */
    public static final int STATUS_CODE_GONE = 410;

    /**
     * HTTP status code for Length Required (411) response.
     * This response code indicates that the server requires a valid `Content-Length` header field in the request.
     */
    public static final int STATUS_CODE_LENGTH_REQUIRED = 411;

    /**
     * HTTP status code for Precondition Failed (412) response.
     * This response code indicates that one or more conditions given in the request's headers evaluated to false when tested on the server.
     */
    public static final int STATUS_CODE_PRECONDITION_FAILED = 412;

    /**
     * HTTP status code for Request Entity Too Large (413) response.
     * This response code indicates that the server is refusing to process a request because the request entity is larger than the server is willing or able to process.
     */
    public static final int STATUS_CODE_REQUEST_TOO_LONG = 413;

    /**
     * HTTP status code for Request-URI Too Long (414) response.
     * This response code indicates that the server is refusing to service the request because the request-target (URI) is longer than the server is willing to interpret.
     */
    public static final int STATUS_CODE_REQUEST_URI_TOO_LONG = 414;

    /**
     * HTTP status code for Unsupported Media Type (415) response.
     * This response code indicates that the server is refusing to service the request because the entity of the request is in a format not supported by the requested resource for the requested method.
     */
    public static final int STATUS_CODE_UNSUPPORTED_MEDIA_TYPE = 415;

    /**
     * HTTP status code for Requested Range Not Satisfiable (416) response.
     * This response code indicates that the server cannot fulfill the requested range.
     */
    public static final int STATUS_CODE_REQUESTED_RANGE_NOT_SATISFIABLE = 416;

    /**
     * HTTP status code for Expectation Failed (417) response.
     * This response code indicates that the server cannot meet the requirements specified in the Expect request header field.
     */
    public static final int STATUS_CODE_EXPECTATION_FAILED = 417;

    /**
     * HTTP status code for Insufficient Space on Resource (419) response.
     * This response code indicates that the server cannot store the representation needed to complete the request.
     */
    public static final int STATUS_CODE_INSUFFICIENT_SPACE_ON_RESOURCE = 419;

    /**
     * HTTP status code for Method Failure (420) response.
     * This response code indicates that the method was not executed on the server due to an unforeseen condition.
     */
    public static final int STATUS_CODE_METHOD_FAILURE = 420;

    /**
     * HTTP status code for Unprocessable Entity (422) response.
     * This response code indicates that the server understands the content type of the request entity and the syntax of the request entity is correct, but it was unable to process the contained instructions.
     */
    public static final int STATUS_CODE_UNPROCESSABLE_ENTITY = 422;

    /**
     * HTTP status code for Locked (423) response.
     * This response code indicates that the source or destination resource of a method is locked.
     */
    public static final int STATUS_CODE_LOCKED = 423;

    /**
     * HTTP status code for Failed Dependency (424) response.
     * This response code indicates that the method could not be performed on the resource because the requested action depended on another action and that action failed.
     */
    public static final int STATUS_CODE_FAILED_DEPENDENCY = 424;

    /**
     * HTTP status code for Internal Server Error (500) response.
     * This response code indicates that the server encountered an unexpected condition that prevented it from fulfilling the request.
     */
    public static final int STATUS_CODE_INTERNAL_SERVER_ERROR = 500;

    /**
     * HTTP status code for Not Implemented (501) response.
     * This response code indicates that the server does not support the functionality required to fulfill the request.
     */
    public static final int STATUS_CODE_NOT_IMPLEMENTED = 501;

    /**
     * HTTP status code for Bad Gateway (502) response.
     * This response code indicates that the server, while acting as a gateway or proxy, received an invalid response from an upstream server.
     */
    public static final int STATUS_CODE_BAD_GATEWAY = 502;

    /**
     * HTTP status code for Service Unavailable (503) response.
     * This response code indicates that the server is currently unable to handle the request due to a temporary overload or maintenance of the server.
     */
    public static final int STATUS_CODE_SERVICE_UNAVAILABLE = 503;

    /**
     * HTTP status code for Gateway Timeout (504) response.
     * This response code indicates that the server, while acting as a gateway or proxy, did not receive a timely response from an upstream server.
     */
    public static final int STATUS_CODE_GATEWAY_TIMEOUT = 504;

    /**
     * HTTP status code for HTTP Version Not Supported (505) response.
     * This response code indicates that the server does not support the HTTP protocol version used in the request.
     */
    public static final int STATUS_CODE_HTTP_VERSION_NOT_SUPPORTED = 505;

    /**
     * HTTP status code for Unauthorized (507) response.
     * This response code indicates that the method could not be performed on the resource because the server is unable to store the representation needed to successfully complete the request.
     */
    public static final int STATUS_CODE_INSUFFICIENT_STORAGE = 507;

    /**
     * This section is to set the message errors or description of the API that are being tested.
     * It only depends on the business rule of the team.
     */
    public static final String INVALID_TOKEN_MESSAGE = "invalid_token";
    public static final String INVALID_TOKEN_DESCRIPTION = "Cannot convert access token to JSON";

    public static final String UNAUTHORIZED_MESSAGE = "unauthorized";
    public static final String UNAUTHORIZED_DESCRIPTION = "Full authentication is required to access this resource";

    private ApiCommon(){    }

}
