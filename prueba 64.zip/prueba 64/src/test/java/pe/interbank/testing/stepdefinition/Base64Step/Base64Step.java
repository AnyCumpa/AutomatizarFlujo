package pe.interbank.testing.stepdefinition.Base64Step;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.thucydides.core.annotations.Steps;
import pe.interbank.testing.endpoint.BaseUrl;
import pe.interbank.testing.task.Base64.Base64Task;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.ByteArrayInputStream;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;
import static pe.interbank.testing.question.generic.CommonQuestion.httpStatusCode;
import static pe.interbank.testing.question.respbase64.respBase64.respBase64;

public class Base64Step {
    @Steps
    BaseUrl base;
    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }
    @When("^ingreso los datos: (.*), (.*), (.*)$")
    public void ingresolosdatos(String dateStartSelected, String dateEndSelected, String Authorization) {
        Serenity.setSessionVariable("dateStartSelected").to(dateStartSelected);
        Serenity.setSessionVariable("dateEndSelected").to(dateEndSelected);
        Serenity.setSessionVariable("Authorization").to(Authorization);
    }
    @And("^envio los datos al servicio del BO$")
    public void enviolosdatosalserviciodelBO() {
        theActorInTheSpotlight().attemptsTo(Base64Task.withData());
    }

    @Then("^mi Status Code es (.*) en el servicio del BO$")
    public void mistatuscodees200(Integer statusCode) {
        String respBase64 = theActorInTheSpotlight().asksFor(respBase64());
        Serenity.setSessionVariable("respBase64").to(respBase64);
        System.out.println("response BO: "+respBase64);
        theActorInTheSpotlight().should(seeThat("the http status code", httpStatusCode(), equalTo(statusCode)));
        try {
            String outputPath = "C:\\Users\\s42246\\OneDrive - Interbank\\Desktop\\prueba 64\\src\\test\\java\\pe\\interbank\\testing\\util\\Base64";
            saveBase64ToExcel(respBase64, outputPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void saveBase64ToExcel(String base64, String filePath) throws IOException {
        byte[] decodedBytes = Base64.getDecoder().decode(base64);
        try (ByteArrayInputStream bis = new ByteArrayInputStream(decodedBytes);
             Workbook workbook = new XSSFWorkbook(bis);
             FileOutputStream fos = new FileOutputStream(filePath)) {
            workbook.write(fos);
        }
    }
}
