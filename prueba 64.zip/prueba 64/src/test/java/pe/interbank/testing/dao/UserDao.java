package pe.interbank.testing.dao;

import pe.interbank.testing.model.TbPerson;
import pe.interbank.testing.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class UserDao extends DBUtil {

    public static TbPerson findPersonbyFirstName(String name) throws Exception {
        ResultSet resultSet = null;
        String sql = "SELECT * FROM Persons WHERE FirstName = ?;";
        TbPerson tbPerson = new TbPerson();

        try (Connection connection = getConnection();
             PreparedStatement pstmnt = connection.prepareStatement(sql)) {
            pstmnt.setString(1, name);
            resultSet = pstmnt.executeQuery();

            if (resultSet.next()) {
                tbPerson.setPersonID(resultSet.getString("PersonID"));
                tbPerson.setLastName(resultSet.getString("LastName"));
                tbPerson.setFirstName(resultSet.getString("FirstName"));
                tbPerson.setAddress(resultSet.getString("Address"));
                tbPerson.setCity(resultSet.getString("City"));
            }


        }
        return tbPerson;
    }

    public static ArrayList<TbPerson> findAllPerson()  throws Exception {
        ResultSet resultSet = null;
        String sql = "SELECT * FROM Persons;";
        ArrayList<TbPerson> listPersons = new ArrayList<>();

        try (Connection connection = getConnection();
             PreparedStatement pstmnt = connection.prepareStatement(sql)) {

            resultSet = pstmnt.executeQuery();

            while(resultSet.next()) {
                TbPerson tbPerson = new TbPerson();
                tbPerson.setPersonID(resultSet.getString("PersonID"));
                tbPerson.setLastName(resultSet.getString("LastName"));
                tbPerson.setFirstName(resultSet.getString("FirstName"));
                tbPerson.setAddress(resultSet.getString("Address"));
                tbPerson.setCity(resultSet.getString("City"));
                listPersons.add(tbPerson);
            }

        }
        return listPersons;
    }




}
