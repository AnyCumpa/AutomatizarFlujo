package pe.interbank.testing.util;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class Base64Util implements Task {

    @Step("{0} envía los datos al servicio del BO")
    public <T extends Actor> void performAs(T actor) {
        String dateStartSelected = Serenity.sessionVariableCalled("dateStartSelected");
        String dateEndSelected = Serenity.sessionVariableCalled("dateEndSelected");
        String Authorization = Serenity.sessionVariableCalled("Authorization");

        actor.attemptsTo(
                Post.to("/your-endpoint")
                        .with(request -> request.header("Authorization", Authorization)
                                .body("{ \"dateStartSelected\": \"" + dateStartSelected + "\", \"dateEndSelected\": \"" + dateEndSelected + "\" }"))
        );
    }

    public static Base64Util withData() {
        return instrumented(Base64Util.class);
    }
}
