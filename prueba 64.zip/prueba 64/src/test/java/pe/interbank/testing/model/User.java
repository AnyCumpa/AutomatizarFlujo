package pe.interbank.testing.model;

import lombok.Getter;
import lombok.Setter;
public class User {

    @Getter @Setter
    private String name;
    @Getter @Setter
    private String job;

    public User(String name, String job) {
        this.name = name;
        this.job = job;
    }

}
