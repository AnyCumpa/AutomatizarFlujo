package pe.interbank.testing.task.ListarEECC;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;
import pe.interbank.testing.endpoint.Endpoint;
import pe.interbank.testing.task.generarTokenEECC.generarTokenEECC;
import pe.interbank.testing.util.JavaUtil;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ListarEECC implements Task {

    private final String ocpApimSubscriptionKey;
    private final String contenttype;
    private final String cu ;
    private final String accountNumber;
    private final String branchCode;
    private final String currency;
    private final String productId;

    private static final String TEMPLATE_LISTAR_ESTADO_DE_CUENTA = "/template/api/ListarEECC.json";

    public ListarEECC() {
        this.cu = Serenity.sessionVariableCalled("cu");
        this.accountNumber = Serenity.sessionVariableCalled("accountNumber");
        this.branchCode = Serenity.sessionVariableCalled("branchCode");
        this.currency = Serenity.sessionVariableCalled("currency");
        this.productId = Serenity.sessionVariableCalled("productId");
        this.contenttype="application/json";
        this.ocpApimSubscriptionKey = "66447c5b273c44b9a8df53a661d236e1";
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        String template = JavaUtil.getTemplate(TEMPLATE_LISTAR_ESTADO_DE_CUENTA);
        actor.attemptsTo(
                Post.to(Endpoint.LISTAR_ESTADO_DE_CUENTA.getEndpoint())
                        .with(requestSpecification -> requestSpecification
                                .relaxedHTTPSValidation()
                                .header("Ocp-Apim-Subscription-Key", ocpApimSubscriptionKey)
                                .header("Content-Type",contenttype)
                                .header("Authorization","Bearer "+ Serenity.sessionVariableCalled("accessTokenEECC"))
                                .body(JavaUtil.getTemplate(TEMPLATE_LISTAR_ESTADO_DE_CUENTA).
                                        replace("{cu}",cu).
                                        replace("{accountNumber}",accountNumber).
                                        replace("{branchCode}",branchCode).
                                        replace("{currency}",currency).
                                        replace("{productId}",productId))
                        )
        );
    }
    public static Performable withData() {
        return instrumented(ListarEECC.class);
    }
}