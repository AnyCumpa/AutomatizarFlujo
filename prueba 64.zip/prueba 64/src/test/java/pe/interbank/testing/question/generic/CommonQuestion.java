package pe.interbank.testing.question.generic;

import io.restassured.module.jsv.JsonSchemaValidator;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Question;

import static pe.interbank.testing.util.JavaUtil.getTemplate;

/**
 * This class provides common questions for retrieving information from API responses.
 * <p>
 *     Note: Don't delete the httpStatusCode and matchSchema methods.
 *     The other ones are to get information about a generic message error. It depends of the business.
 * </p>
 * @author Joham Romucho
 */
public class CommonQuestion {

    /**
     * Retrieves the error name from the last API response.
     * This method can be modified according to the business rule.
     *
     * @return A Question object representing the error name.
     */
    public static Question<String> error() {
        return Question.about("The error name")
                .answeredBy(
                        actor -> SerenityRest.lastResponse().xmlPath().getString("InvalidTokenException.error")
                );
    }

    /**
     * Retrieves the error description from the last API response.
     * This method can be modified according to the business rule.
     *
     * @return A Question object representing the error description.
     */
    public static Question<String> errorDescription() {
        return Question.about("The error description")
                .answeredBy(
                        actor -> SerenityRest.lastResponse().xmlPath().getString("InvalidTokenException.error_description")
                );
    }

    /**
     * Retrieves the HTTP status code from the last API response.
     * This method can't be modified or deleted.
     * @return A Question object representing the HTTP status code.
     */
    public static Question<Integer> httpStatusCode() {
        return Question.about("The http status code")
                .answeredBy(
                        actor -> SerenityRest.lastResponse().getStatusCode()
                );
    }

    /**
     * Validates if the response matches the specified JSON schema.
     * This method can't be modified or deleted.
     *
     * @param PATH_SCHEMA The path to the JSON schema file.
     * @return A Question object representing whether the response matches the schema.
     * @throws AssertionError if the schema validation fails.
     */
    public static Question<Boolean> matchSchema(String PATH_SCHEMA) {
        return Question.about("The response is valid")
                .answeredBy(
                        actor -> {
                            try {
                                Serenity.recordReportData().withTitle("JSON schema to validate").andContents(getTemplate("/"+PATH_SCHEMA));
                                SerenityRest.lastResponse().then().assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath(PATH_SCHEMA));
                                return true;
                            } catch (AssertionError e) {
                                throw new AssertionError("Schema validation failed: " + e.getMessage(), e);

                            }
                        }
                );
    }
}
