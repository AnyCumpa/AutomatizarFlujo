package pe.interbank.testing.model;

import lombok.Getter;
import lombok.Setter;
public class TbPerson {

    @Getter @Setter
    private String PersonID;

    @Getter @Setter
    private String LastName;

    @Getter @Setter
    private String FirstName;

    @Getter @Setter
    private String Address;

    @Getter @Setter
    private String City;

    public TbPerson(String PersonID, String LastName, String FirstName, String Address, String City) {
        this.PersonID = PersonID;
        this.LastName = LastName;
        this.FirstName = FirstName;
        this.Address = Address;
        this.City = City;

    }

    public TbPerson() {

    }

    @Override
    public String toString() {
        return "TBPersons{" +
                "PersonID=" + PersonID +
                ", LastName='" + LastName + '\'' +
                ", FirstName='" + FirstName + '\'' +
                ", Address=" + Address +
                ", City=" + City +
                '}';
    }
}
