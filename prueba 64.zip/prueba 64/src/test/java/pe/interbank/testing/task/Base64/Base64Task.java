package pe.interbank.testing.task.Base64;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.serenitybdd.screenplay.rest.interactions.Post;
import pe.interbank.testing.endpoint.Endpoint;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class Base64Task implements Task {
    private final String dateStartSelected;
    private final String dateEndSelected;
    private final String Accept;
    private final String AcceptLanguage;
    private final String Authorization;
    private final String Connection;
    private final String OcpApimSubscriptionKey;
    private final String Origin;
    private final String Referer;
    private final String SecFetchDest;
    private final String SecFetchMode;
    private final String SecFetchSite;
    private final String UserAgent;
    private final String secchua;
    private final String secchuamobile;


    public Base64Task() {
        this.dateStartSelected = Serenity.sessionVariableCalled("dateStartSelected");
        this.dateEndSelected = Serenity.sessionVariableCalled("dateEndSelected");
        this.Accept = "application/json, text/plain, */*";
        this.AcceptLanguage = "es,es-ES;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6";
        this.Authorization =Serenity.sessionVariableCalled("Authorization");
        this.Connection= "keep-alive";
        this.OcpApimSubscriptionKey= "e1ec309c5da54220a6db09b7cfd3ac27";
        this.Origin= "https://streu2c003ctsuat01.z20.web.core.windows.net";
        this.Referer= "https://streu2c003ctsuat01.z20.web.core.windows.net/";
        this.SecFetchDest= "empty";
        this.SecFetchMode= "cors";
        this.SecFetchSite= "cross-site";
        this.UserAgent= "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0";
        this.secchua= "\"Chromium\";v=\"122\", \"Not(A:Brand\";v=\"24\", \"Microsoft Edge\";v=\"122\"";
        this.secchuamobile= "?0";
    }
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Get.resource(Endpoint.BO_CTS.getEndpoint()+
                        "?dateStartSelected=" + dateStartSelected +
                        "&dateEndSelected=" + dateEndSelected)
                        .with(requestSpecification -> requestSpecification
                                .relaxedHTTPSValidation()
                                .header("Accept", Accept)
                                .header("Accept-Language",AcceptLanguage)
                                .header("Authorization",Authorization)
                                .header("Connection",Connection)
                                .header("Ocp-Apim-Subscription-Key",OcpApimSubscriptionKey)
                                .header("Origin",Origin)
                                .header("Referer",Referer)
                                .header("Sec-Fetch-Dest",SecFetchDest)
                                .header("Sec-Fetch-Mode",SecFetchMode)
                                .header("Sec-Fetch-Site",SecFetchSite)
                                .header("User-Agent",UserAgent)
                                .header("sec-ch-ua",secchua)
                                .header("sec-ch-ua-mobile",secchuamobile)
                        )
        );
    }
    public static Performable withData() {
        return instrumented(Base64Task.class);
    }
}
