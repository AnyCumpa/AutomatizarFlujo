package pe.interbank.testing.stepdefinition.listar;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.thucydides.core.annotations.Steps;
import pe.interbank.testing.endpoint.BaseUrl;
import pe.interbank.testing.task.ListarEECC.ListarEECC;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;
import static pe.interbank.testing.question.generic.CommonQuestion.httpStatusCode;
import static pe.interbank.testing.question.respListarEECC.respListarEECC.respListarEECC;

public class ListarEECCStep {
    @Steps
    BaseUrl base;

    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }
    @When("^ingreso los datos: (.*), (.*), (.*), (.*), (.*)$")
    public void ingresolosdatos(String cu, String accountNumber, String branchCode, String currency, String productId) {
        Serenity.setSessionVariable("cu").to(cu);
        Serenity.setSessionVariable("accountNumber").to(accountNumber);
        Serenity.setSessionVariable("branchCode").to(branchCode);
        Serenity.setSessionVariable("currency").to(currency);
        Serenity.setSessionVariable("productId").to(productId);
    }
    @And("^envio los datos al servicio de listar eecc$")
    public void enviolosdatosalserviciodelistareecc() {
        theActorInTheSpotlight().attemptsTo(ListarEECC.withData());
    }

    @Then("^mi Status Code es (.*) en el servicio de Listar estado de cuenta$")
    public void mistatuscodees200(Integer statusCode) {
        String responseListarEECC = theActorInTheSpotlight().asksFor(respListarEECC());
        Serenity.setSessionVariable("responseListarEECC").to(responseListarEECC);
        System.out.println("response ListarEECC: "+responseListarEECC);
        theActorInTheSpotlight().should(seeThat("the http status code", httpStatusCode(), equalTo(statusCode)));
    }
}
