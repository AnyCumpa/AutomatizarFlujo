package pe.interbank.testing.question.respListarEECC;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Question;

public class respListarEECC {
    public static Question<String> respListarEECC() {
        return Question.about("respListarEECC")
                .answeredBy(
                        actor -> SerenityRest.lastResponse().getBody().asPrettyString()
                );
    }
}
