package pe.interbank.testing.endpoint;

import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.thucydides.core.util.EnvironmentVariables;

/**
 * This class provides utility methods for common operations in Java.
 * It contains methods for loading properties, retrieving templates, queries, and variables,
 * generating random numbers and codes, converting lists to strings, and parsing data tables.
 * The methods in this class are static and can be accessed without creating an instance of the class.
 * @author Joham Romucho
 */
public class BaseUrl {

    private static EnvironmentVariables environmentVariables;

    public String getUrlExtern() {
        System.out.println("url es " + EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("environments.uat.restapi.baseurl.extern"));
        return EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("environments.uat.restapi.baseurl.extern");
    }

    public static String getBDUrl() {
        EnvironmentSpecificConfiguration envConf = EnvironmentSpecificConfiguration.from(environmentVariables);
        String bdType = envConf.getProperty("bd.manager");
        String server =envConf.getProperty("bd.server");
        String bd = envConf.getProperty("bd.BD");
        String port = envConf.getProperty("bd.port");
        return "jdbc:"+bdType+"://"+server+":"+port+";database="+bd+";encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;";
    }
}

