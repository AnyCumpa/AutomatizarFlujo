package pe.interbank.testing.question.respbase64;

import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Question;

public class respBase64 {
    public static Question<String> respBase64() {
        return Question.about("respBase64")
                .answeredBy(
                        actor -> SerenityRest.lastResponse().getBody().asPrettyString()
                );
    }
}
