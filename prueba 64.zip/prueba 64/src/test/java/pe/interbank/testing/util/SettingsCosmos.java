// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

package pe.interbank.testing.util;

import org.apache.commons.lang3.StringUtils;

public class SettingsCosmos {
    // Replace MASTER_KEY and HOST with values from your Azure Cosmos DB account.
    // The default values are credentials of the local emulator, which are not used in any production environment.
    // <!--[SuppressMessage("Microsoft.Security", "CS002:SecretInNextLine")]-->
    public static String MASTER_KEY =
            System.getProperty("ACCOUNT_KEY",
                    StringUtils.defaultString(StringUtils.trimToNull(
                                    System.getenv().get("ACCOUNT_KEY")),
                            "0KJT1E8BznUfs4F3daSt07Fr0eYQDy4R0ANan9PvlDAJxpRRAqomJmSgWEAP7YeyDn6yrxS4Ri2BeXtWu3FlKQ=="));

    public static String HOST =
            System.getProperty("ACCOUNT_HOST",
                    StringUtils.defaultString(StringUtils.trimToNull(
                                    System.getenv().get("ACCOUNT_HOST")),
                            "https://acdbeu2c003ctsdev01.documents.azure.com:443"));
}
