package pe.interbank.testing.runner;


import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.json.JSONObject;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.interbank.testing.util.XrayUtil;

import java.util.Properties;

import static pe.interbank.testing.util.JavaUtil.properties;

/**
 * This class is for configure the Cucumber runner.
 */
@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        plugin = {"pretty", "json:target/cucumber/cucumber.json"},
        glue = {"pe.interbank.testing.stepdefinition"},
        features = "classpath:feature",
        tags = "@obtenerToken"
)
public class CucumberTestSuite {
    private static final Logger LOGGER = LoggerFactory.getLogger(CucumberTestSuite.class);

    @AfterClass
    public static void integrationWithXrayAndJira() throws Exception{

        Properties properties = properties();
        boolean attachZipReportInJira = Boolean.parseBoolean(properties.getProperty("jira.integration.attachment"));
        String jiraIntegration = properties.getProperty("jira.integration.source");

        if(jiraIntegration.equals("local")) {
            LOGGER.info("SYNCHRONIZING FEATURES");
            XrayUtil.synchronizingFeatures();

            LOGGER.info("IMPORTING TEST EXECUTION RESULTS");
            String importExecutionStr = XrayUtil.importTestExecutionResults();

            JSONObject importExecutionJson = new JSONObject(importExecutionStr);
            String keyTE = importExecutionJson.getString("key");

            if (attachZipReportInJira) {
                LOGGER.info("ATTACHING EVIDENCE TO TEST EXECUTION");
                XrayUtil.attachEvidence(keyTE);
            }
        }

    }
}
