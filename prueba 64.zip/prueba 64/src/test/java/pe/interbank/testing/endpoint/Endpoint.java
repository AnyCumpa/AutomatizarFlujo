package pe.interbank.testing.endpoint;

import net.serenitybdd.core.Serenity;

/**
 * This class provides utility methods for common operations in Java.
 * It contains methods for loading properties, retrieving templates, queries, and variables,
 * generating random numbers and codes, converting lists to strings, and parsing data tables.
 * The methods in this class are static and can be accessed without creating an instance of the class.
 * @author Joham Romucho
 */
public enum Endpoint {
    LISTAR_ESTADO_DE_CUENTA("/ecd/handle/v1/account-statements/periods"),
    TOKEN_ESTADO_DE_CUENTA("/ecd/security/oauth2/token"),
    BO_CTS("/cudi/cts/admin/v1/payment-request/report");

    private final String endpoint;

    Endpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getEndpoint() {
        return endpoint;
    }
}
