# Problemas frecuentes

1. En caso se haya instalado una versión superior o igual al JDK 17, entonces se debe considerar siempre añadir el siguiente método para desactivar la validación del certificado SSL en cada request que se realice. Este método se llama *relaxedHTTPSValidation()* y para que no devuelva la siguiente excepción se debería añadir en cada request.

__Excepción:__
```java
Caused by: javax.net.ssl.SSLHandshakeException: PKIX path building failed: sun.security.provider.certpath.SunCertPathBuilderException: unable to find valid certification path to reques
```
__Ejemplo de su implementación:__
```Java
actor.attemptsTo(
                Get.resource(Endpoint.API_GET_CATEGORIES.getEndpoint())
                        .with(requestSpecification -> requestSpecification
                                .relaxedHTTPSValidation()
                                .header("Authorization", token)
                                .header("Ocp-Apim-Subscription-Key", ocpApimSubscriptionKey)
                                .header("Cookie", cookie)
                                .queryParam("currencyCode", currencyCode)
                                .queryParam("branchCode", branchCode)
                                .pathParam("accountId", accountId)
                        )
        );
```
2. De igual manera si está trabajando con la versión del JDK 11, y su API le devuelve el error anteriormente mostrado usar el mismo método para desactivar la validación del cerrtficado SSL.
