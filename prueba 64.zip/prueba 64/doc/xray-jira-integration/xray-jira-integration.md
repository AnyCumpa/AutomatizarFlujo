# Integración con Xray y Jira

- [Configuracion previa](#configuracion-previa)
    * [Tipos de variables](type-variables/type-variables.md)
    * [Generación de variables](#generacin-de-variables)
- [Integración local y remota de Xray y Jira](#integracin-local-y-remota-de-xray-y-jira)
    * [Integración local de Xray y Jira](#integracin-local-de-xray-y-jira)
        + [Grupo de variables del usuario](xray-jira-execution/xray-jira-local-execution.md)
        + [Configuración del properties para ejecución local](xray-jira-execution/xray-jira-local-execution.md)
    * [Integración remota de Xray y Jira](#integracin-remota-de-xray-y-jira)
        + [Grupo de variables](xray-jira-execution/xray-jira-remote-execution.md)
        + [Configuración del properties para ejecución remota](xray-jira-execution/xray-jira-local-execution.md)
- [Flujos integrados](#flujos-integrados)
    * [Sincronización de feature](#sincronizacin-de-feature)
    * [Publicación de resultados de pruebas](#publicacin-de-resultados-de-pruebas)
    * [Publicación del reporte de pruebas](#publicacin-del-reporte-de-pruebas)

## Configuracion previa

Para realizar la integración de Xray y Jira de manera local y remota se requieren tener las siguientes variables como
variables de entorno.

### Tipos de variables
> Las variables que se manejan se puede ver en el siguiente [link](type-variables/type-variables.md).

### Generación de variables
Posterior a saber cuantas variables requiere la integración de Xray y Jira, en esta sección se explicará a a generar las variables que no se indicarón en la sección anterior.
#### Generación de las credenciales para Jira

> Para generar las credenciales de Jira ver el siguiente [link](generate-xray-jira-variables/generate-variables-jira.md).

#### Generación de las credenciales para Xray

> Para generar las credenciales de Xray ver el siguiente [link](generate-xray-jira-variables/generate-variables-xray.md).

#### Generación de variables por squad

> Para generar las variables por squad ver el siguiente [link](generate-xray-jira-variables/generate-variables-squad.md).

## Integración local y por pipeline de Xray y Jira
El proyecto de automatización se puede configurar para que las integraciones con Xray y Jira se realice de manera local o remota, es decir mediante el pipeline.

### Integración local de Xray y Jira
> Para configurar la ejecución de la integración de manera local ver el siguiente [link](xray-jira-execution/xray-jira-local-execution.md).

### Integración remota de Xray y Jira
> Para configurar la ejecución de la integración por el pipeline ver el siguiente [link](xray-jira-execution/xray-jira-remote-execution.md).

## Flujos integrados

Los flujos que se integraron al template de pruebas automatizadas de servicios son para realizar la sincronización de
los escenarios de prueba, la publicación de los resultados sobre el test execution y la publicación del zip del reporte.
En las siguientes secciones detallaremos las consideraciones que hay que tener en la escritura de los escenarios para la
integración.

### Sincronización de feature

> Para revisar las consideraciones para la sincronización de los features ver el siguiente [link](xray-jira-flows-integrated/sync-features.md).

### Publicación de resultados de pruebas

> Para revisar las consideraciones para la publicación de resultados de pruebas ver el siguiente [link](xray-jira-flows-integrated/publish-tests-results.md).

### Publicación del reporte de pruebas

> Para revisar las consideraciones para la publicación del reporte de pruebas ver el siguiente [link](xray-jira-flows-integrated/publish-report.md).
