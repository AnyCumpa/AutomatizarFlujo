# Integración local con Xray y Jira
La integración con Xray y Jira se puede realizar de manera local al término de una ejecución de escenarios automatizados
de pruebas.

Para realizar la integración exitosamente se debe tener en consideración los siguientes puntos:

## Grupo de variables del usuario

Después de tener todas las credenciales generadas, para el funcionamiento correcto del proyecto se debe tener agregadas
estás variables al entorno del sistema.

1. En primer lugar, abrir las variables del usuario.

   ![env-variables-s1.png](../../image/xray-jira-integration/env-variables/env-variables-s1.png)

2. Y en esta sección, agregar todos los tipos de variables (por usuario, por squad y a nivel cross).

   ![env-variables-s2.png](../../image/xray-jira-integration/env-variables/env-variables-s2.png)

3. Finalmente, se deberá reiniciar el dispositivo y se podrá ejecutar exitosamente la integración de manera local.


## Configuración del properties para ejecución local

Desde el archivo del proyecto *serenity.properties* hay una propiedad, la cual permite seleccionar el tipo de
integración de manera local o con el pipeline. Para que la integración sea de manera local, se debe tener la siguiente
propiedad:

```properties
jira.integration.source=local
```