# Integración remota con Xray y Jira
La integración con Xray y Jira también se puede realizar de manera remota desde el pipeline al término de las tareas del
pipeline.

Para realizar la integración exitosamente se debe tener en consideración los siguientes puntos:

## Grupo de variables

Posterior a la generación de las variables, se debe crear un grupo de variables sobre el cuál se agregaran todas las
variables indicadas (por usuario, por squad y cross).

1. Para el desarrollo del template de pruebas automatizadas se consideró la creación del grupo *ibkteam-devops-uat*
   Sobre está sección deberá seleccionar el grupo de variables correspondiente a su equipo.

   ![group-variables-s1.png](../../image/xray-jira-integration/group-variables/group-variables-s1.png)

2. Luego, al ingresar al grupo de variables seleccionado, podrá visualizar todas las variables que existen en el grupo.

   ![group-variables-s2.png](../../image/xray-jira-integration/group-variables/group-variables-s2.png)

3. Después, deberá agregar todas las variables descritas anteriormente.

   ![group-variables-s3.png](../../image/xray-jira-integration/group-variables/group-variables-s3.png)

4. Finalmente, podrá realizar la ejecución del pipeline de manera exitosa.

## Configuración del properties para ejecución remota

Desde el archivo del proyecto *serenity.properties* hay una propiedad, la cual permite seleccionar el tipo de
integración de manera local o con el pipeline. Para que la integración sea mediante el pipeline, se debe tener la
siguiente propiedad:

```properties
jira.integration.source=remote
```
