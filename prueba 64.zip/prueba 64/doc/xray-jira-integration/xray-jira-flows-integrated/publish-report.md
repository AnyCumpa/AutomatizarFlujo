# Publicación del reporte de pruebas

La publicación del reporte de pruebas se realizará sobre el test execution, está configuración permitirá subir la
evidencia automáticamente a la incidencia del Test Execution. Sin embargo, como el almacenamiento es limitado en la
herramienta de Jira, entonces esta integración es configurable, es decir que se puede omitir este paso en caso ya se
tuviera un reporrte de pruebas.

La configuración es realizada desde el serenity.properties. Si en caso no se quisiera adjuntar el reporte se debe
agregar el sisguiente campo.

```properties
jira.integration.attachment=false
```

En caso contrario, se debería actualizar el valor del campo a __true__

```properties
jira.integration.attachment=true
```

Nota:

* La configuración de este cambio para la ejecución desde el pipeline, previamente se debería subir los cambios al
  repositorio.
* Para más información del funcionamiento del flujo dar
  click [aquí](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-issue-attachments/#api-rest-api-3-issue-issueidorkey-attachments-post).
