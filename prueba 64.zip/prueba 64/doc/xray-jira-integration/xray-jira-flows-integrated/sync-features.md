# Sincronización de feature

Para la sincronización de los escenarios de prueba, al terminar la ejecución de pruebas el proyecto de automatización se
comprime la carpeta /feature y su contenido es publicado en el API de Xray para importar los archivos features. Cabe
recalcar que los escenarios que se sincronizan son independientes del tag que se envía para ejecutar el proyecto.

Para realizar correctamente la sincronización se tienen las siguientes consideraciones:

1. El escenario debe tener el *tag* correspondiente a la id de la incidencia en Xray. Si en caso se añade y este existe
   entonces se sincronizará el escenario del feature en el tablero de testing. Sin embargo, en caso no exista se creará
   el test con los tags sobre el escenario como *label* en la incidencia.

Ejemplo:

```gherkin
@TXDM-51
Feature: Crear Usuario

  @TXDM-12
  Scenario: Crear usuario por número de documento
    Given el administrador Joham recibe una solicitud de crear un usuario
    When se registra al usuario con dni 83789723
    Then el usuario debería acceder a la aplicación exitosamente

  @TXDM-213
  Scenario Outline: Crear usuario incorrectamente
    Given el administrador Joham recibe una solicitud de crear un usuario
    When se registra al usuario <nombre> <apellido> incorrectamente con <dni>
    Then el usuario debería acceder a la aplicación exitosamente
    Examples:
      | nombre  | apellido | dni      |
      | Ernesto | Lopez    | 83789723 |
      | Ernesto | Lopez    | 837897AA |

```

En este ejemplo se puede observar que se tienen 2 escenarios uno con un id de la incidencia en Xray y el otro con un id
que no existe. Al momento de importar el archivo, si la incidencia TXDM-12 existe entonces actualizará el escenario. Sin
embargo, para el otro caso, asumiendo que existe el escenario, como no existe el id entonces __creará el test con el
label TXDM-213__. Además, como están bajo la etiqueta del feature, las vinculará a la principal TXDM-51.

2. Si en caso no se añade el tag con el id de la incidencia, entonces buscará dentro del feature aquel que tenga el
   identificador único por feature __id__ o el mismo nombre del escenario. Si finalmente no encuentra el feature
   seleccionado lo creará.

Ejemplo:

```gherkin
@TXDM-51
Feature: Crear Usuario

  @HappyPath
  Scenario: Crear usuario por número de documento
    Given el administrador Joham recibe una solicitud de crear un usuario
    When se registra al usuario con dni 83789723
    Then el usuario debería acceder a la aplicación exitosamente

  @id:1
  Scenario Outline: Crear usuario incorrectamente
    Given el administrador Joham recibe una solicitud de crear un usuario
    When se registra al usuario <nombre> <apellido> incorrectamente con <dni>
    Then el usuario debería acceder a la aplicación exitosamente
    Examples:
      | nombre  | apellido | dni      |
      | Ernesto | Lopez    | 83789723 |
      | Ernesto | Lopez    | 837897AA |

```

En este ejemplo se observa que se tienen 2 escenarios, ninguno con el tag de la incidencia.

* Para el primer escenario entonces si no existiera el archivo por primera vez lo crearía con el nombre del caso igual
  al nombre del escenario y el tag HappyPath. Y la segunda vez que se importe se buscará por el nombre del escenario,
  por lo que se recomienda que los escenarios que se creen para el Test Case sean los mismos para el escenario en
  Gherkin.
* Para el segundo escenario, si no existiera en el tablero lo crearía con el nombre del escenario. Y al momento de
  ejecutarlo por segunda vez buscaría por la ruta del archivo y por el id asociado al feature, si lo encuentra lo
  actualiza.
* Finalmente vinculará cada test case al tag del feature.

Nota:

* Para evitar duplicación de escenarios asegurarse que el nombre del escenario esa el mismo que la prueba e
  identificarlo por el tag del Test Case (TXDM-123).
* Para más información del funcionamiento del flujo dar
  click [aquí](https://docs.getxray.app/display/XRAYCLOUD/Importing+Cucumber+Tests+-+REST).
