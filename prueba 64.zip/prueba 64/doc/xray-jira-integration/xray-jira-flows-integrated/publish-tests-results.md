# Publicación del reporte de pruebas

La publicacción de los resultados de pruebos permitirá mantener actualizado el estado de nuestras ejecuciones evitando
estar actualizando de manera manual grandes grupos de pruebas. A diferencia de la sincronización de escenarios, en este
caso solo se actualizarán los escenarios que se ejecuten bajo cierto tag (ej. @regresion).

Para realizar esta función se deben tener las siguientes consideraciones:

1. Los escenarios que estén seleccionados con el tag de ejecución, deberán estar previamente creados en el tablero de
   Xray.
2. Para vincularse al test execution, se deberá añadir la etiqueta del test execution a nivel del feature, si no se
   agregará se crearía uno por cada ejecución. En caso se quisiera ejecutar diferentes escenarios de múltiples features
   se deberá añadir la etiqueta del test execution sobre tales features.

Ejemplo:

```gherkin
@TXDM-51
Feature: Crear Usuario

  @TXDM-12 @regresion
  Scenario: Crear usuario por número de documento
    Given el administrador Joham recibe una solicitud de crear un usuario
    When se registra al usuario con dni 83789723
    Then el usuario debería acceder a la aplicación exitosamente

  @TXDM-13
  Scenario Outline: Crear usuario incorrectamente
    Given el administrador Joham recibe una solicitud de crear un usuario
    When se registra al usuario <nombre> <apellido> incorrectamente con <dni>
    Then el usuario debería acceder a la aplicación exitosamente
    Examples:
      | nombre  | apellido | dni      |
      | Ernesto | Lopez    | 83789723 |
      | Ernesto | Lopez    | 837897AA |

```

```gherkin
@TXDM-51
Feature: Editar Usuario

  @TXDM-14 @regresion
  Scenario: Editar usuario por número de documento
    Given el administrador Joham recibe una solicitud de actualizar la información de un usuario
    When se edita la información del usuario con dni 83789723
    Then el usuario debería ver su nueva información

```

En el siguiente ejemplo se ejecutarán todos los escenarios bajo el tag de *@regresion* y los tags que están al nivel del
feature son los del test execution. Entonces se espera que los escenarios se vinculen al test execution y sobre este se
añadirán los test que estuvieron con el tag de la incidencia.

Nota:

* Para más información del funcionamiento del flujo dar
  click [aquí](https://docs.getxray.app/display/XRAYCLOUD/Import+Execution+Results+-+REST).
