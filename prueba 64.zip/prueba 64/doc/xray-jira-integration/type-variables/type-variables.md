# Tipos de variables

De acuerdo a las variables que se requieren, se definen 3 tipos de grupo de variables, por
usuario, por squad y a nivel cross.

## Variables a nivel cross

Este tipo de variables serán las mismas para todos los equipos con el template de automatización de pruebas.
Nota: La variable REPOSITORY_NAME, por el momento será a nivel cross.

```
XRAY_HOSTNAME : xray.cloud.getxray.app
JIRA_HOSTNAME : interbank.atlassian.net
REPOSITORY_NAME : dso-api-testing
```

## Variables por squad

Este tipo de variables dependerá del equipo específicamente del proyecto en Jira, la variables PROJECT_KEY equivale al
prefijo de las incidencias y el PROJECT_ID equivale al id del proyecto, esta última variable se puede obtener con la
siguiente colección de postman.

Se tiene por ejemplo estos valores:

```
PROJECT_ID : 123
PROJECT_KEY : TXM
```

## Variables por usuario

Las variables por usuario, deberán ser generadas por cada QA del equipo. La variable JIRA_USERNAME equivale al correo
del miembro con dominio intercorp, mientras que las demás variables serán generadas en la siguiente sección.

```
JIRA_USERNAME : generic@intercorp.com.pe
JIRA_CLIENT_ID  : *****
JIRA_CLIENT_SECRET : *****
JIRA_API_TOKEN : *****
```