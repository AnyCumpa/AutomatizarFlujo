# Generación de las credenciales para Xray
En esta sección se indicará el paso a paso para crear las credenciales de Xray.

1. En primer lugar, para generar el client secret y client id de xray se debe ir a la sección de aplicaciones y
   seleccionar __Xray__

   ![xray-credential-generation-s1](../../image/xray-jira-integration/xray-credential-generation/xray-credential-generation-s1.png)

3. Después en la barra lateral izquierda, seleccionar la opción de __Claves de API__

   ![xray-credential-generation-s2](../../image/xray-jira-integration/xray-credential-generation/xray-credential-generation-s2.png)

4. Luego, en esta sección podrá crear una clave de API para cualquier usuario. Seleccionar __Crear Clave de API__

   ![xray-credential-generation-s3](../../image/xray-jira-integration/xray-credential-generation/xray-credential-generation-s3.png)

5. A continuación deberá seleccionar el usuario al que se le asignará las credenciales.

   ![xray-credential-generation-s4](../../image/xray-jira-integration/xray-credential-generation/xray-credential-generation-s4.png)

6. Luego, dar click en la opción de generar las claves.

   ![xray-credential-generation-s5](../../image/xray-jira-integration/xray-credential-generation/xray-credential-generation-s5.png)

7. Finalmente, deberá guardar las llaves creadas.

   ![xray-credential-generation-s6](../../image/xray-jira-integration/xray-credential-generation/xray-credential-generation-s6.png)

Nota:

* El líder técnico de QA deberá realizar la creación de las llaves, ya que por motivos de acceso no todos tienen acceso
  a la sección de Crear Claves de API.
* Para más información ver el siguiente [link](https://docs.getxray.app/display/XRAYCLOUD/Global+Settings%3A+API+Keys).
