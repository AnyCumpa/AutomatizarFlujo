# Generación de variables por squad

Para obtener las variables que van a variar por equipo, se deben realizar los siguientes pasos:

1. La variable REPOSITORY_NAME hace referencia al nombre del repositorio, este debería seguir los lineamientos
   propuestos, por ejemplo:

```text
REPOSITORY_NAME = <squad>-api-testing

Ej.
. dso-api-testing
. bim-api-testing
...
```

2. La variable PROJECT_KEY, como se mencionó anteriormente es el prefijo de las incidencias de Jira. Se puede obtener de
   la siguiente manera:

   ![key-project-s1.png](../../image/xray-jira-integration/key-project-s1.png)

3. La variables PROJECT_ID hace referencia al id del proyecto de Jira. Para obtener esta variable se requiere tener el usuario de jira, el api token de jira y el *key* del proyecto de Jira ; y para obtenerlo puede seguir los siguiente pasos:

   - Primero ingresar el endpoint para realizar la consulta.
   ```
   https://interbank.atlassian.net/rest/api/3/project/:project_key
   ```
   ![project-info-url.png](../../image/xray-jira-integration/project-info-url.png)

   - Luego, ingresar el project_key en el request.

   ![project-info-request.png](../../image/xray-jira-integration/project-info-request.png)

   - Después, ingresar el usuario de Jira y el API token de Jira en la sección de __Auth__

   ![project-info-auth.png](../../image/xray-jira-integration/project-info-auth.png)

   - Finalmente podrá ejecutar el request y el campo __id__ es el ID del proyecto.

   ![project-info-response.png](../../image/xray-jira-integration/project-info-response.png)
