# Generación de las credenciales para Jira
En esta sección se indicará el paso a paso para crear el API token de Jira.

1. Para generar el API token de Jira, en primer lugar, se debe acceder a la sección de __Administrar cuenta__

   ![jira-api-token-generation-s1.png](../../image/xray-jira-integration/jira-api-token-generation/jira-api-token-generation-s1.png)

2. Después acceder a la sección de  __Seguridad__

   ![jira-api-token-generation-s2.png](../../image/xray-jira-integration/jira-api-token-generation/jira-api-token-generation-s2.png)

3. Sobre está sección, ya se disponibiliza la sección de API token. Seleccionar la opción de __Crear y administrar API
   tokens__

   ![jira-api-token-generation-s3.png](../../image/xray-jira-integration/jira-api-token-generation/jira-api-token-generation-s3.png)

4. Podrá visualizar los API tokens si en caso ya hubiera algunos generado. Después, dar click al botón de __Crear API
   token__

   ![jira-api-token-generation-s4.png](../../image/xray-jira-integration/jira-api-token-generation/jira-api-token-generation-s4.png)

5. Ingresar una etiqueta para identificar al token.

   ![jira-api-token-generation-s5.png](../../image/xray-jira-integration/jira-api-token-generation/jira-api-token-generation-s5.png)

6. Y el token se generará exitosamente. Nota: Importante copiar el API token de Jira desde este momento.

   ![jira-api-token-generation-s6.png](../../image/xray-jira-integration/jira-api-token-generation/jira-api-token-generation-s6.png)

Nota:

* El token de Jira lo puede generar cualquier usuario con una cuenta, esta llave les servirá para todos los proyectos
  asociados al usuario.
* Para más información dar click al
  siguiente [link](https://support.atlassian.com/atlassian-account/docs/manage-api-tokens-for-your-atlassian-account/)
* Las APIs de Jira no tienen tiempo de expiración, durán hasta que se elimine la cuenta del usuario. Ver
  detalle [aquí](https://community.atlassian.com/t5/Jira-Software-questions/Jira-api-token-expiry/qaq-p/1545981).
