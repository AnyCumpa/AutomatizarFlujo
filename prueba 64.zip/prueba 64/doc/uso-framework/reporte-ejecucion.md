# Reporte de ejecución

## Campos customizables
Actualmente en el reporte de ejecución se visualiza 5 campos configurables desde el archivo [*serenity.properties*](../../serenity.properties), los cuales son los siguientes:

| Nombre                   | Propiedad                              | Descripción                                                                                                            |
|--------------------------|----------------------------------------|------------------------------------------------------------------------------------------------------------------------|
| Nombre del proyecto      | serenity.project.name                  | Este campo es modificable y se podrá cambiar para especificar el nombre del proyecto.                                  |
| Versión de la aplicación | report.customfields.ApplicationVersion | Este campo permite configurar la versión de la aplicación que se está probando.                                        |
| Ambiente                 | report.customfields.environment        | Este campo es modificable y permite visualizar en qué ambiente se están ejecutando las pruebas. Ej. Uat, Dev, Staging. | 
| Usuario                  | report.customfields.user               | Este campo es modificable y permite especificar el usuario que está ejecutando las pruebas.                            |                                                                                                      
| Equipo                   | report.customfields.squad              | Este campo es modificable y permite visualizar el nombre del equipo que está ejecutando las pruebas automatizadas.     |

![report-execution-custom-fields](../image/uso-framework/report-execution-custom-fields.png)

> Nota: <br>
> El nombre del proyecto debe seguir el siguiente formato {squad}-api-testing. Ej. bim-api-testing <br>
> La versión de la aplicación es diferente  a la versión del proyecto, esta está especificado en el pom <br>
> Para saber más a detalle cada sección del reporte de ejecución revisar el siguiente [link](https://serenity-bdd.github.io/docs/reporting/the_serenity_reports).

# Documentación en vivo
Este término hace referencia a generar la documentación automáticamente con las especificaciones de los criterios de aceptación de las HUs y de cómo funciona el sistema bajo prueba.
- Es una  documentación, porque describe como funciona la aplicación junta a qué requerimientos están implicados, de tal manera que un usuario normal lo pueda entender. Entonces, los reportes generados pueden ser usados tanto por el equipo para un pase a producción o como evidencia ante una auditoría.
- Es en vivo, porque es generado de manera automática y por lo que siempre está al día.

La documentación es usada en los equipos no solo para evidenciar que el software funciona como lo esperado, sino también para dejar en documentación acerca de cómo funciona todo el sistema en conjunto.

La sección de __*Requirements*__ en el reporte de Serenity, es la sección donde se puede encontrar la documentación en vivo. Sobre esta sección se personalizaron los siguientes campos:

1. Requirements Jerarchy: los reportes de serenity te permiten la facilidad de visualizar toda la estructura de los requerimientos escritos y el estado de aquelleas que se ejecutaron.
   
    ![report-execution-requeriments-jerarchy](../image/uso-framework/report-execution-requirements-jerarchy.png)

2. Requerimients description: a parte de la jerarquía, Serenity BDD tiene la opción personalizar la sección de Requerimientos, permitiendo agregar una descripción y una imagen a esta sección, permitiendo agregar una descripción a la HU que se está ejecutando. Este texto es configurable desde el archivo [readme.md](../../src/test/resources/readme.md) y la imagen es modificable en la carpeta [asset](../../src/test/resources/asset).
   
   ![report-execution-requeriments-description](../image/uso-framework/report-execution-requirements-description.png)

3. Test Results: así como el reporte de Serenity te permite documentar acerca del funcionamiento del software, la sección de *Tests Results* te permite visualizar el reporte de pruebas que pasaron, fallaron, pendientes, etc.

   ![report-execution-test-result](../image/uso-framework/report-execution-test-results.png)

> Nota: <br>
> Para saber más a detalle acerca del concepto de documentación en vivo ver el siguiente [link](https://serenity-bdd.github.io/docs/reporting/living_documentation)