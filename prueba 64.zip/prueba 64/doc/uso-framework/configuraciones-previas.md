# Configuraciones previas
## Java Development Kit
1. Descargar la versión del JDK superior al 11
2. Abrir el buscador de Windows y buscar *Variables del sistema* y seleccionar la primera opción
3. En la sección de variables del sistema se debe crear la variable **"JAVA_HOME"** y añadirle la ruta del jdk instalado, de la siguiente manera:
```
Name  : JAVA_HOME
Value : C:\Program Files\Java\jdk-11.0.17 
```
6. En la sección de variables del sistema se debe crear o editar, si ya existe, la variable **"PATH"**, y agregar la variable *%JAVA_HOME%\bin*, de la siguiente manera:
```
Name  : Path
Value : %JAVA_HOME%\bin
```
>Nota: <br>
> Para versiones superiores a Java 17 se debe desactivar la verficación del certificado SSL en cada prueba. En la sección de __Problemas Frecuentes__ se indicará como añadirlo en su automatización.
## Apache maven
1. Descargar la versión de maven 3.6.12
2. Abrir el buscador de Windows y buscar *Variables del sistema* y seleccionar la primera opción
3. En la sección de variables del sistema se debe crear la variable **"M2_HOME"** y añadirle la ruta del maven, de la siguiente manera:
```
Name  : M2_HOME
Value : C:\Program Files\apache-maven-3.6.12
```
6. En la sección de variables del sistema se debe crear o editar, si ya existe, la variable **"PATH"**, y agregar la variable *%M2_HOME%\bin*, de la siguiente manera:
```
Name  : Path
Value : %M2_HOME%\bin
```