# Convenciones para los commits
La especificación de los cmmits es importante para que todo el equipo pueda entender los cambios que se aplican sobre un proyecto, para esto se propone trabajar con las siguientes convenciones:

## Formato del commit
Un commit debe tener el siguiente formato:
```
<type>[optional scope]: <description>
```
Donde:
- type: tipo de commit que se hace referencia (doc, fix, feat, etc)
- scope: alcance del cambio realizado
- description: descripción del commit para un mayor entendimiento del cambio aplicado

## Tipos de commits permitidos
1. fix: este tipo de commit implica que el cambio es un arreglo de algún bug encontrado o un malfuncionamiento del software
2. feat: este tipo de commit implica añadir una nueva funcionalidad al proyecto
3. docs: este tipo de commit implica un cambio en la documentación del proyecto
4. test: cada vez que se pruebe una nueva funcionalidad (nueva integración, configuracion del reporte) se deben realiar pruebas, para esto se usa este tipo de commit
5. refactor: este tipo de commit implica realizar un cambio sin alterar funcionalidad
7. perf: para cambios de codigo que ayudan a tener un mejor performance se usa este tipo de commit
8. chore: este tipo de commit implica realizar cambios en archivos que no tengan que ver con el codigo fuente del framework
9. revert: este tipo de cambio implica revertir un commit hacia una versión antigua del proyecto

> Para saber más a cerca de las convenciones para realizar commits ver el siguiente [link](https://www.conventionalcommits.org/en/v1.0.0/).