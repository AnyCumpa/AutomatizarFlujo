## Principios SOLID

SOLID representa los principios de diseño de software orientado a objetos, los cuales permiten que el software sea
mantenible, escalable y de fácil comprensión. Los principios SOLID son los siguientes:

1. Principio de responsabilidad única (SRP)
2. Principio de abierto/cerrado (OCP)
3. Principio de sustitución de Liskov (LSP)
4. Principio de segregación de interfaces (ISP)
5. Principio de inversión de dependencias

| Principios <br/>SOLID | Definición                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|-----------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| SRP                   | Este principio estables que una clase o módulo únicamente debería tener una funcionalidad definida. Esto facilita el mantenimiento del software, ya que se evita tener clases demasiados grandes díficil de leer y por lo tanto de mantener.                                                                                                                                                                                                                                                                                                                     |
| OCP                   | Establece que las entidades deberían estar abiertas para extensión, pero cerradas para modificación, por ejemplo: en caso se tenga una librería que requiere de funciones adicionales para que funcione en un entorno específico, la entidad estaría cerrada si no se pudiera modificar el código fuente de la librería, pero estaría abierta si pudeiera añadir estructuras de datos. <br/> Pese a que estos conceptos sean opuestos, mediante la herencia de clases se podría modificar la clase hija de acuerdo al entorno manteniendo la clase padre intacta |
| LSP                   | Este principio define que los objetos de clases padres podrían ser reemplazados por objetos de clases ihjas sin romper la aplicación.                                                                                                                                                                                                                                                                                                                                                                                                                            |
| ISP                   | Este principio establece que usuarios no debería verse obligadosa depender de interfaces que no se utilizan, se recomienda crear interfaces más pequeñas y específicas.                                                                                                                                                                                                                                                                                                                                                                                          |
| DIP                   | Sostiene que los módulos de alto nivel no deberían depender de módulos de bajo nivel, sino que ambos deberían depender de abstracciones (interfaces).                                                                                                                                                                                                                                                                                                                                                                                                            |

En la siguiente sección se especifca la relación entre los principios SOLID y el patrón de diseño Screenplay.

> Para ver más detalle de los principios SOLID dar click en el siguiente link.

## Screenplay

El POM (Page Object Model) es también un patrón de diseño el cuál una clase para almacenar todos los elementos (
localizadores) y acciones sobre una página. En primera instancia, puede ser útil y fácil de entender este patrón de
diseño, pero cuando las páginas crecen en funcionalidad y en tamaño, entonces las clases se hacen cada vez más grandes y
con más métodos y atributos, por lo que no cumple con el principio SRP ni con el OCP.

En respuesta a este problema del POM, Screenplay cumplé con estos principios, ya que cada tarea que realiza un actor se
define en una clase separada cumpliendo de esta manera el principio SRP.

Este patrón de diseño se definen los siguientes conceptos:

1. *Roles* -> ¿Para quién es?
2. *Goals* -> ¿Para qué están aquí y qué se espera?
3. *Tasks* -> ¿Qué necesitan para alcanzar los objetivos?
4. *Actions* -> ¿Cómo se completará cada tarea?

En el siguiente gráfico se puede visualizar la relación entre estos conceptos.

![screenplay-pattern](../image/screenplay-pattern.png)

Cómo se observa en la siguiente figura, *Screenplay* define al actor quien es la aquel que interactúa con el sistema
bajo prueba (app, web, api). Para esto el actor realiza tareas (*Tasks*) que le permitirá alcanzar sus objetivos (*
Goals*). ¿Cómo realizará estás acciones? para este caso el actor tiene habilidades, tales como buscar en la web,
consultar un api, realizar un query; que le ayudan a realizar las tareas. Adicionalmente un actor puede realizar
preguntas a cerca del sistema bajo prueba, para que puede comparar entre el valor esperado y el actual de sus acciones.

En resumen,

| Screenplay | Definición                                                                                                                                                        |
|------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor      | Es quien interactúa con el sistema bajo prueba, puede definirse más de uno depediendo de la casuística.                                                           |
| Tasks      | Son las tareas que realiza el actor para alcanzar el objetivo (resultado de la pruebas).                                                                          |
| Question   | Son las preguntas que realiza un actor para obtener el estado __actual__ del sistema.                                                                             |
| Habilities | El actor tiene habilidades que le permite realizar acciones, tales como: buscar un elemento en una web, una consulta en la base de datos, o una consulta a un API |

## Serenity BDD

En base a la explicación del patrón de diseño, Screenplay, se puede escoger la herramienta para implementar el esquema
anteriormente mencionado.

El template de automatización de pruebas de servicios utiliza Serenity BDD, debido a que combina las ventajas del
desarrollo guiado por comportamiento junto al patrón de diseño Screenplay. Además de la legilibilidad de los métodos
implementados para seguir el patrón de diseño ayuda a un miembro nuevo del equipo de entender el proyecto de
automatización; y junto a las opciones para personalizar y ver el detalle de las pruebas, el reporte de ejecución de
Serenity BDD brinda muchas opciones de acuerdo al requerimiento.

> Nota: <br>
> Para ver el detalle del desarrollo orientado al comportamiento ver el siguiente link.<br>
> Para ver el detalle de la implementación de screenplay sobre serenity BDD ver el
> siguiente [link](https://serenity-bdd.github.io/docs/screenplay/screenplay_fundamentals).

## Dependencias
Se usan las siguientes dependencias para el uso del patrón de Screenplay con cucumber y Serernty BDD.
JUNIT?
```xml
<dependency>
    <groupId>net.serenity-bdd</groupId>
    <artifactId>serenity-screenplay-rest</artifactId>
    <version>${serenity.version}</version>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>net.serenity-bdd</groupId>
    <artifactId>serenity-junit</artifactId>
    <version>${serenity.version}</version>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>net.serenity-bdd</groupId>
    <artifactId>serenity-screenplay</artifactId>
    <version>${serenity.version}</version>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>net.serenity-bdd</groupId>
    <artifactId>serenity-core</artifactId>
    <version>${serenity.version}</version>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>net.serenity-bdd</groupId>
    <artifactId>serenity-screenplay-webdriver</artifactId>
    <version>${serenity.version}</version>
    <scope>test</scope>
</dependency>
```

## Caso de Uso
