# GraphQL

GraphQL es un lenguaje de consulta y manipulación de datos abierto. A diferencia de las tradicionales API REST, GraphQL ofrece una forma más eficiente y flexible de solicitar y proporcionar datos entre el cliente y el servidor. A continuación, se presentan las principales características de GraphQL:

## Características de GraphQL

| Característica                                        | Descripción                                                                                                                       |
|-------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------|
| Lenguaje de consulta flexible                         | Permite a los clientes solicitar solo los datos específicos que necesitan, evitando la sobrecarga de recibir datos no utilizados. |
| Resolución eficiente de consultas                     | Permite solicitar múltiples recursos en una sola llamada a la API, evitando la necesidad de realizar múltiples solicitudes REST.  |
| Especificación del cliente                            | El cliente especifica qué datos necesita, lo que permite una evolución flexible de las API sin afectar a los clientes existentes. |
| Flexibilidad en la estructura de datos                | Los clientes pueden recibir diferentes vistas y combinaciones de datos según sus necesidades específicas.                         |

## Uso en el template

El proyecto de automatización permite realizar las consultas de GrahpQL mediante el siguiente flujo:

### 1. Escritura del query
El query que se va a usar se debe guardar en la carpeta de template/graphql/../query, previamente deberá haber estructurado la carpeta de graphql en base a las entidades que se probará, en este ejemplo de es película.
```graphql
query allFilms {
  allFilms {
    films {
      title
    }
    pageInfo{
      startCursor
    }
  }
}
```
Para guardar el query se debe tener en consideración que debe representar una funcionalidad, en este caso es de listar todas las películas. En caso se requieran pasar variables al query, se crean en la carpeta de [template/graphql/../variable](../../src/test/resources/template/graphql/movie/variable) en este caso se guardan como un template de las variables que se enviaran.
```json
{
  "filmId": "{filmId}"
}
```

### 2. Desde el Task
Únicamente se deben especificar el query y las variables, para que después en el Task correspondiente se arme el cuerpo del request, se realiza de la siguiente manera:
```java
...
public class GetMovie implements Task {

    private static final String TEMPLATE_GENERIC_WITH_VARIABLES = "/template/graphql/genericWithVariables.json";
    private static final String PATH_QUERY = "/template/graphql/movie/query/getFilmById.graphql";
    private static final String PATH_VARIABLES = "/template/graphql/movie/variable/getFilmByIdVar.json";
    ...
    @Override
    @Step("{0} search a movie by id #filmId")
    public <T extends Actor> void performAs(T actor) {
        String queryGetMovies = JavaUtil.getQuery(PATH_QUERY, empty());

        String variable = JavaUtil.getVariables(PATH_VARIABLES)
                .replace("{filmId}",filmId);

        actor.attemptsTo(
                Post.to(Endpoint.GRAPHQL_NETLIFY.getEndpoint())
                        .with(query -> query
                                .contentType(ContentType.JSON)
                                .body(JavaUtil.getTemplate(TEMPLATE_GENERIC_WITH_VARIABLES)
                                        .replace("{operationName}", "film")
                                        .replace("{query}", queryGetMovies)
                                        .replace("{variables}", variable))
                        )
        );
    }
}
```
Como se puede observar a partir de la ruta del query se obtiene el query y de la misma forma las variables que se enviaran. Finalmente, para armar el cuerpo del request, como en este caso se tienen un query con variables, se debe usar el template genericWithVariables.json para armar el cuerpo que se enviará.

