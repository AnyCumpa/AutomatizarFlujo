# JSON Schema

Son representaciones estructurales de documentos JSON, estos permiten definir las reglas y restricciones para validar la
estructura, tipos de datos y el contenido de un objeto JSON.

## Beneficios

- Permite describir la data existente en los objetos JSON
- Permite realizar una validación de la data acorde a la documentación del documento
- Provee una limpia estructura de los requerimientos del documento JSON entendible para la máquina y humano

## Caso de uso

Dado que tenemos un API para crear usuarios, actualmente este es el repsonse que se obtiene:

```json
{
  "name": "Julio",
  "job": "Contador",
  "id": 1234
}
```

Uno de los requerimientos es validar que todos los campos que devualeva sean obligatorio y cada campo deban ser cadenas
de letras a excepción del id que debe ser un número entero.

Para cumplir la validación se podría obtener cada campo independientemente con una pregunta del actor, usando el patrón
screenplay, pero en caso la cantidad de campos del *response* aumentara dificultaría su validación. Para esto se crea el
siguiente __JSON Schema__.

```json
{
  "type": "object",
  "properties": {
    "name": {
      "type": "string"
    },
    "job": {
      "type": "string"
    },
    "id": {
      "type": "integer"
    }
  },
  "required": [
    "name",
    "job",
    "id"
  ]
}
```

En el siguiente esquema se cumple con los requerimientos,

1. El *response* al ser un objeto JSON se especifica en el response en el campo *type*
2. Y el tipo de data de cada campo se especifica dentro del objeto *properties*
3. Para especificar los campos requeridos se guardan dentro de una lista en el campo *required*

Cómo se observa con el uso de JSON Schemas se pueden validar varios requerimientos, a partir de un solo documento JSON.

## Uso en el Template de Pruebas Automatizadas de servicios

El template usa la siguiente dependencia de rest assured para realizar la comparación entre el esquema y el documento
JSON.

```xml

<dependency>
    <groupId>io.rest-assured</groupId>
    <artifactId>json-schema-validator</artifactId>
    <version>5.3.0</version>
</dependency>
```

En la carpeta de [preguntas comunes](../../src/test/java/pe/interbank/testing/question/generic/CommonQuestion.java) se tiene implementado un
método que compara el esquema JSON en cierta ruta con la última respuesta que se envía de serenity.

```java
public static Question<Boolean> matchSchema(String PATH_SCHEMA){
        return Question.about("The response is valid")
        .answeredBy(
            actor->{
                try{
                    Serenity.recordReportData().withTitle("JSON schema to validate").andContents(getTemplate("/"+PATH_SCHEMA));
                    SerenityRest.lastResponse().then().assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath(PATH_SCHEMA));
                    return true;
                }catch(AssertionError e){
                    throw new AssertionError("Schema validation failed: "+e.getMessage(),e);

                }
            }
        );
}
```

Debido a su implementación el uso de esta pregunta es fácilmente implementada en los steps que comparan el resultado
actual con el esperado (Then).

```java
@Then("^el usuario debería registrarse correctamente$")
public void elUsuarioSeIngresoCorrectamente(){
        String PATH_SCHEMA="schema/user/createUser.json";
        ...
        theActorInTheSpotlight().should(
            seeThat("The response match",matchSchema(PATH_SCHEMA))
        );
}
```

> Para ver más detalle de los JSON Schemas dar click en el siguiente link.
