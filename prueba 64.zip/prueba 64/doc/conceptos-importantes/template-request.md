# Uso de Templates
Actualmente en el proyecto de automatización se proponen diferentes formas de realizar las consultas a las APIs, el uso de los templates es una forma de manejar los requests que se realizarán.

## Funcionamiento
Debido a la documentación existente del API (swagger, excel, etc) se puede armar directamente el *body* del request que se enviará. Por lo que para usar los templates se deben seguir los siguientes pasos:

1. Definir el cuerpo del request con los valores por defecto, es decir como es un template del request entonces inicialmente no tendrán el valor por cada campo. Por ejemplo:

```json
{
  "id": "{id}",
  "category": {
    "id": "{categoryId}",
    "name": "{categoryName}"
  },
  "name": "{name}",
  "photoUrls": "{photoUrls}",
  "status": "{status}"
}
```
En este request se manejan 3 tipos de datos principales, integer, string y listas, y se observa que no existe diferencia en como definir el request. Sin embargo, la diferencia existe en cómo asignar los valores a los campos del request.
> Nota: <br>
> 1. Se recomienda mantener la misma estructura de paquetes que en los features, steps definitions, tasks y questions. <br>
> 2. Si son requests para APIs trabajarlo dentro de la carpeta api, pero si es de un query de graphql usar la carpeta graphql y almacenar sus querys dentro.
 
2. Después, se debe dirigir al Task dónde se realizará la consulta al API y cuando el actor intente consultar al API se llamará al método para obtener el template. Como el método convierte el template a un string, entonces con el método __*replace("{valor}",newValue)*__ se cambiará la palabra por defecto por los atributos de la clase. Por ejemplo:
```java
@Override
    @Step("{0} add a pet with petId #petId")
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                Post.to(Endpoint.API_CREATE_PET.getEndpoint())
                        .with(request -> request
                                .body(JavaUtil.getTemplate(TEMPLATE_ADD_PET)
                                        .replace("\"{id}\"", id.toString())
                                        .replace("\"{categoryId}\"", categoryId.toString())
                                        .replace("{categoryName}",categoryName)
                                        .replace("{name}",name)
                                        .replace("\"{photoUrls}\"", listToString(photoUrls))
                                        .replace("{status}",status)
                                )
                        )
        );
        LOGGER.info(SerenityRest.lastResponse().prettyPrint());
    }
```
> Nota:<br>
> 1. Se recomienda usar una palabra por defecto única. <br>
> 2. Para cuando se tengan listas dentro del request se debe trabajar como en el caso del campo photoUrls, volviendo la lista un string con el método listToString (de JavaUtil).