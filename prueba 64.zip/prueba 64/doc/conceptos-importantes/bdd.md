# Desarrollo Orientado al Comportamiento (BDD)

# ¿Qué es?
El desarrollo orientado al comportamiento es una metodología colaborativa de entrega de software. El cuál consiste en usar ejemplos concretos  para la escritura de tests de aceptación de alta calidad y entregar las funcionalidades que importan al negocio.

![bdd-importancia](../image/bdd-importancia.png)

Es importante solicitar ejemplos concretos como una pequeña historia en un estadío temprano del sprint, ya que permitirá al  equipo:

1. Identificar e ilustrar cuáles serán la reglas de negocio.
2. El tener las reglas de negocio ejemplificadas ayuda a plantear preguntas a cerca de los requerimientos.
3. Los ejemplos son orientados en el "qué" y no en "cómo" se realizaron.
4. Permiten hacernos pensar acerca de los resultados esperados y objetivos.

En resumen, los ejemplos concretos permiten ejemplificar reglas de negocio para evitar malentendidos en el equipo para construir las funcionalidades que son importantes para el negocio.

## ¿Cómo funciona?

BDD encaja bien en un ambiente ágil, y la reunión de 3 amigos es una ceremonia que se debería de tener una buena idea acerca del requerimiento, mediante alguna técnica como *example mapping* o *feature mapping*. Para esto principalmente deben estar 3 roles:
1. Un representante del negocio 
2. Un desarrollador
3. Un tester.

![bdd-3-amigos](../image/bdd-3-amigos.png)

En la reunión de 3 amigos es dónde se realizan los ejemplos y contra ejemplos para ilustrar la necesidad del negocio. De esta manera no solo se logra un entendimiento compartido de las reglas de negocio, sino se evitan presunciones acerca de estos. 

Entonces, después de ilustrar las reglas de negocio se deben formular las necesidades del negocio, en este caso usando Gherkin para redactar los escenarios que serán ejecutados después del desarrollo.

Luego, mientras se desarrolle el requerimiento el equipo de QA se dedicará a automatizar las especificaciones redactadas en Gherkin. La automatización usualmente es realizada con Cucumber y siguiendo un patrón de diseño en este caso Screenplay. 

Después, se deben validar que todos los tests hayan cumplido exitosamente todas las necesidades del negocio. Para que finalmente sean presentadas al representante del negocio.

![bdd-workflow](../image/bdd-workflow.png)

> Nota:<br>
> Si quiere saber más detalle del desarrollo orientado al comportamiento dar click a este [link](https://johnfergusonsmart.com/behaviour-driven-development-3-minute-rundown/).