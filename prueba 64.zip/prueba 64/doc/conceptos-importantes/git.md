## Trunk Based Development (TBD)
Como parte de los lineamientos se propone el trabajo con TBD, el cual es un enfoque de desarrollo de software que se enfoca en la integración frecuente de cambios de código hacia una rama principal compartida (*trunk*). 

> Para ver más a detalle el flujo de trabajo con TBD ver el siguiente [link](https://interbankpe.sharepoint.com/:p:/r/sites/CoordinacinInternaDevOpsArquitectura/Shared%20Documents/General/Lineamientos%20y%20Procedimientos/Repositorio%20y%20branching/Branching%20-%20Trunk%20Based%20Development%20v1.1.pptx?d=w60eddf1a60d8457292ca5d9ab55edb47&csf=1&web=1&e=tBEJhV).
 
## Convenciones para los commits

> Para ver el detalle de las convenciones de los commits ver el siguiente [link](../conceptos-importantes/commit-convention.md).