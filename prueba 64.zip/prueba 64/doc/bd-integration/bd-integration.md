# Integración con una Base de Datos
La validación de la data usualmente se realiza a nivel de API; sin embargo, a veces es necesario realizar validaciones de la data sobre la base de datos, ya que de esta manera se puede asegurar de una mejor manera la integridad de de los datos.

En base a esto, el proyecto cuenta con métodos para realizar conexiones y consultas sobre una base de datos.

## Configuración previa
Previamente a realizar la conexión de la base de datos, se debe tener cargadas las siguientes variables de entorno. Para esto hay 2 consideraciones, cuando se ejecuta el proyecto desde un pipeline o de manera local.

> Para revisar la configuración previa para realizar consultas sobre la base de datos revisar el siguiente [link](../bd-integration/configuracion-previa.md).

## Integración con el template
En la siguiente sección se revisará el flujo de trabajo que se debe seguir para integrar la base de datos con el template.
> Para revisar el flujo de trabajo de la base de datos con el template revisar el siguiente [link](../bd-integration/bd-workflow.md).
