# Integración con el template
Se deben tener las siguientes consideraciones para interactuar con la base de datos:

1. En el archivo [serenity.conf](../../src/test/resources/serenity.conf) se debe especificar los parámetros de configuración de la base de datos, puede ser por ambiente DEV, UAT o STAGING.
```json
#
environments {
    default {
        ...
        bd {
            manager = "manager"
            server = "server"
            port ="1234"
            BD ="bdName"
        }
    }
    dev {
        ...
    }
    uat {
        ...
    }
}
```

2. Posterior a ingresar los parámetros de la base de datos, se debe definir el query que se realizará en la base de datos, en caso se requiera validar la existencia de un dato creado por API, por ejemplo.
```roomsql
SELECT * FROM Persons WHERE FirstName = "nombre";
```
3. Después definir el query de búqueda, se implementaría la clase asociada a la acción en la carpeta [dao](../../src/test/java/pe/interbank/testing/dao), sobre esta después se debería implementar el método para ejecutar el query. Esta clase hereda de la clase que realiza la conexión con la base de datos, para que únicamente esté enfocada a ejecutar el query.
```java
public class UserDao extends DBUtil {
    public static TbPerson findPersonbyFirstName(String name) throws Exception {
        ResultSet resultSet = null;
        String sql = "SELECT * FROM Persons WHERE FirstName = ?;";
        TbPerson tbPerson = new TbPerson();

        try (Connection connection = getConnection();
             PreparedStatement pstmnt = connection.prepareStatement(sql)) {
            pstmnt.setString(1, name);
            resultSet = pstmnt.executeQuery();

            if (resultSet.next()) {
                tbPerson.setPersonID(resultSet.getString("PersonID"));
                tbPerson.setLastName(resultSet.getString("LastName"));
                tbPerson.setFirstName(resultSet.getString("FirstName"));
                tbPerson.setAddress(resultSet.getString("Address"));
                tbPerson.setCity(resultSet.getString("City"));
            }


        }
        return tbPerson;
    }
    ...
}
```
4. Finalmente, el método devolverá la persona encontrada como un objeto y cómo en este caso se quiere validar que el usuario creado por el API exista en la BD se deberá crear una Question que ejecute el método implementado.
```java
    public static  Question<String> firstNameDB(String name) {
        return Question.about("The first name of the DB")
                .answeredBy(
                        actor -> {
                            try {
                                TbPerson person = findPersonbyFirstName(name);
                                Serenity.recordReportData().withTitle("Database evidence").andContents(String.valueOf(person));
                                return person.getFirstName();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                ).asString();
    }
```
> Nota: <br>
> Es importante, para mostrar la evidencia de que la persona existe en la base de datos, usar el siguiente método.
```java
Serenity.recordReportData().withTitle("Database evidence").andContents(String.valueOf(person));
```
> Las clases creadas sobre la carpeta dao deben estar asociadas al objeto de pruebas, por ejemplo: <br>
> *"Si se quisiera validar que los perimsos fueron creados para un socio, entonces la clase sería __PermisosDao__"*