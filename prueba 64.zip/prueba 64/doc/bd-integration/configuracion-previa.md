# Configuración previa

## Ejecución local
En caso se quisiera ejecutar de manera local las variables BD_USERNAME y BD_PASSWORD deben ser agregadas como variables de entorno del usuario. Estas variables son proporcionadas, en su mayoría, por el líder técnico de desarrollo o de QA.
```
BD_USERNAME : username
BD_PASSWORD : password1234$
```
Para agregar las variables se debe seguir los siguientes pasos:
1. Se debe buscar las variables de sistema y en caso no se tenga permisos usar las variables de su cuenta.
   
   ![env-variables-s1](../image/xray-jira-integration/env-variables/env-variables-s1.png)

2. Finalmente, en la sección de variables de entorno añadir la variable BD_USERNAME y BD_PASSWORD
   
   ![env-variables-s2](../image/xray-jira-integration/env-variables/env-variables-s2.png)

## Ejecución con pipeline
En caso se quisiera ejecutar con un pipeline, las variables deberían ser agregadas al grupo de variables definido por el equipo. Para añadir las variables al grupo, seguir los siguientes pasos:

1. Seleccionar la sección de *Library*

   ![group-variables-s1](../image/xray-jira-integration/group-variables/group-variables-s1.png)

2. Luego, se debería visualizar todas las variables del grupo.

   ![group-variables-s2](../image/xray-jira-integration/group-variables/group-variables-s2.png)

3. Finalmente, se debe agregar una nueva variable.

   ![group-variables-s3](../image/xray-jira-integration/group-variables/group-variables-s3.png)
