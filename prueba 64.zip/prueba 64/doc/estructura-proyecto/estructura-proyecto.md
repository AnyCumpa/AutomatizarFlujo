# Estructura del template de pruebas

En esta sección se realizará una descripción de las carpetas del proyecto:

| Nombre de los paquetes | Descripción                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| devops                 | El proyecto de automatización tiene integrado un template del pipeline para la testing continuo del sistema bajo prueba. Para esto existen dos subcarpetas importantes: <br> 1. __pipelines__: en esta subcarpeta se encuentra configurado el grupo de variables que usa el pipeline junto a los parámetros de entrada que recibe al momento de la ejecución. <br> 2. __templates__: en esta subcarpeta se encuentra el template que realiza las tareas del pipeline, tales como la ejecución del proyecto, la publicación del reporte de pruebas y la integración Xray y Jira. |
| doc                    | La documentación del proyecto de pruebas automatizadas se encuentra en esta carpeta. La documentación abarca temas como la configuración previa, el uso del patrón de diseño Screen, las integraciones con Xray y Jira, entre otros más.                                                                                                                                                                                                                                                                                                                                        |
| dao                    | Actualmente el proyecto cuanto con un método para la conexión de base datos y para esto se requiere realizar los querys o modificaciones sobre la BD para esto creamos DAOs (Data Access Object), clases que incluirán los métodos que realizaran las acciones sobre la base de datos (querys, insert, update) y en caso se requieran modelar la respuesta guardará el resultado del query en la clase o estructura de datos correspondiente (lista, hashmap, etc).                                                                                                             |
| endpoint               | Dentro de esta carpeta se encuentran un clase y un enum importantes para las consultas a las APIs.<br> 1. __BaseUrl__: sobre esta clase se tienen los métodos para acceder a las URLs bases de las APIs que se prueban. <br> 2. __Endpoint__: en este enum se guardan el nombre de los endpoints junto a su valor correspondiente, es útil para acceder directamente sin tener la url en cada consulta al API.                                                                                                                                                                  |
| model                  | Sobre este paquete se guardarán todas las clases que van a modelar los resultados o consultas de las APIs o también el resultado de los querys sobre la base de datos.                                                                                                                                                                                                                                                                                                                                                                                                          |
| question               | Este paquete forma parte del uso del patrón Screenplay, se utiliza para almacenar las clases *Questions* y *CommonQuestions* que preguntarán por ciertos campos de los resultados de las APIs o de una Base de datos o si coinciden con el JSON Schema esperado.                                                                                                                                                                                                                                                                                                                |
| runner                 | Sobre esta carpeta se guarda el runner de Cucumber para ejecutar el proyecto, sobre el cuál se puede modificar los tags de los escenarios que se van a ejecutar. Además, se tienen los métodos que llaman a la integración Xray y Jira después de toda la ejecución de pruebas.                                                                                                                                                                                                                                                                                                 |
| stepdefinition         | En esta carpeta se encuentran las clases que implementarán la escritura de los escenarios en Gherkin. Se implementan las validaciones entre los valores esperados y actuales, los métodos que realizan la consulta al API y para setear la URL base de los servicios al inicio de cada prueba.                                                                                                                                                                                                                                                                                  |
| util                   | En esta carpeta se encuentran las clases útiles para realizar integraciones con Jira y Xray, conexión a base de datos, generación de códigos aleatorios, etc.                                                                                                                                                                                                                                                                                                                                                                                                                   |
| asset                  | Esta carpeta almacena la imagen representativa que se mostrará en la sección de requerimientos del reporte generado por Serenity. Se recomiendan que las dimensiones sean menor a 500x100, pero manteniendo es proporcion, de tal manera de tener una buena visualización en el reporte.                                                                                                                                                                                                                                                                                        |
| feature                | En esta carpeta se guardarán tanto subcarpetas que agrupen features asociados a una funcionalidad, y dentro los features que guardarán los requerimientos en lenguaje Gherkin por cada una de las HUs.                                                                                                                                                                                                                                                                                                                                                                          |
| schema                 | En la sección de conceptos importantes se comentó el uso de los JSON schemas para realizar las validaciones de las respuestas de las APIs, para esto se deben crear los schemas y estos se guardarán en esta carpeta.                                                                                                                                                                                                                                                                                                                                                           |
| template               | Para realizar los requests a las APIs se pueden trabajar creando clases o creando templates de los requests, estos se guardan en esta carpeta. Y además, el se tienen templates tanto para consultas a APIs como querys de GraphqQL.                                                                                                                                                                                                                                                                                                                                            |

> Nota: <br>
> En la carpeta de devops se recomienda no modificar todas las tareas para una correcta ejecución de las pruebas e integración con Xray y Jira.

## Recomendaciones
Para facilitar el mantenimiento del proyecto y su entendimiento, se recomienda seguir las siguiente consideraciones:
1. Al momento de crear cualquier paquete siempre crearlo en minúscula y singular sin ningún carácter especial.
```
✔ stepdefintion
❌ stepDefinition
❌ StepDefinition
❌ step_definition
❌ stepdefinitions
```
2. Las clases deben ser creadas en mayúsculas, con el formato CamelCase y en singular.
```
✔ UserStepDefintion
❌ userstepdefinition
❌ UserStepDefinitions
❌ user_step_definition
❌ Userstepdefinition
```
3. Por cada HUs normalmente se crea una nueva funcionalidad, para esto antes de escribir los features se deben crear las subcarpetas que irán dentro de cada paquete explicado, por ejemplo si tuviera una HU para crear Permisos se debería tenerla siguiente estructura:
````text 
dso-api-testing/                        
...
├───src                             
│   └───test                        
│       ├───java                    
│       │   └───pe                  
│       │       └───interbank
│       │           └───testing
...
│       │               ├───question
│       │               │   └───generic
│       │               │   └───permiso
│       │               ├───stepdefinition
│       │               │   └───permiso
│       │               ├───task
│       │               │   └───permiso
...
│       └───resources
│           ├───asset
│           ├───feature
│           │   └───permiso
│           ├───schema
│           │   └───permiso
│           └───template
│               ├───api
│               │   └───permiso (*)
│               └───graphql
│                   └───permiso (*)
│                       ├───query
│                       └───variable
└─── 
````